#include<math.h>
#include<stdio.h>
#include<string.h>


//Holly Walker C3021739 (230217397)

//Quadratic equation function: takes the a,b,c values and calculates the roots
void quadraticEquation(float a, float b, float c)
{
  float root1,root2,real,imaginary;
  //Calculates discrimminant (this is to check the amount of roots/if they're imaginary)
  float discrimminant = (b*b) - (4*a*c);
  printf("Enter either 'e' for exponential result or 'f' for float result\n");
  char dataType[2];
  scanf("%s", &dataType);
  if((strcmp(dataType,"e"))) {
    if (strcmp(dataType,"f")) {
      printf("Invalid input: must be either 'e' (exponential) or 'f' (float)");
      exit(0);
    }
  }
  //Roots are real and different
  if(discrimminant>0) {
    //Quadratic formula
    root1 = (-b + sqrt(discrimminant)) / (2*a);
    root2 = (-b - sqrt(discrimminant)) / (2*a);
    //float form
    if(!(strcmp(dataType,"f"))) {
      printf("root1 is %f \nroot2 is %f", root1, root2);
    }
    //exponential form
    else {
      printf("root1 is %e \nroot2 is %e", root1, root2);
    }
  }
  //Roots are real and the same
  if(discrimminant==0) {
    root1 = -b / (2*a);
    root2 = root1;
    //float form
    if(!(strcmp(dataType,"f"))) {
      printf("root 1 and root2 is %f;", root1);
    }
    //exponential form
    else {
      printf("root 1 and root2 is %e;", root1);
    }  
  }
  //Roots are imaginary and different
  if(discrimminant<0) { 
    real =(-b) / (2.0*a);
    imaginary = sqrt(-discrimminant) / (2*a);
    //float form
    if(!(strcmp(dataType,"f"))) {
      printf("root 1 is %f+%fi \nroot 2 is %f-%fi", real, imaginary, real, imaginary);
    }
    //exponential form
    else{
      printf("root 1 is (%e)+%fi \nroot 2 is (%e)-%fi", real, imaginary, real, imaginary);
    }  
  }
}

//Continually asks if the user would like to enter more quadratic equations
void mainLoop() {
  int exit = 0;
  while(exit == 0) {
    printf("\nWould you like to enter another quadratic equation? (type y for yes, n for no)\n");
    char answer[2];
    scanf("%s", &answer);
    if (strcmp(answer,"n")) {
      //if the answer is not n or y, an error message is shown
      if (strcmp(answer,"y")) {
        printf("Invalid input: must be either 'y' (yes) or 'n' (no)");
      }
      //if the answer is y, it prompts the user to enter a,b and c and then calls the quadratic equation
      else {
        printf("Enter a: \n");
        float a;
        scanf("%f", &a);
        printf("Enter b: \n");
        float b;
        scanf("%f", &b);
        printf("Enter c: \n");
        float c;
        scanf("%f", &c);
        quadraticEquation(a,b,c);
      }
    }
    //if the answer in n, the while loop exits
    else {
      exit = 1;
    }
  }
}

//Main program
void main( int argc, char *argv[] )
{
  if(argc>1)
  {
    //If there's 3 arguments, it will use them as parameters for the quadraticEquation function
    if(argc==4)
    {
      float a = atof(argv[1]);
      float b = atof(argv[2]);
      float c = atof(argv[3]);
      quadraticEquation(a,b,c);
    }
    //Incorrect number of arguments prints error message
    else {
        printf("Invalid amount of arguments: either 3 arguments for values a,b and c or none(for manual input)");
    }
  }
  else {
    //If no arguments are entered in the command line, a b and c are manually entered by the user
    printf("Enter a: \n");
    float a;
    scanf("%f", &a);
    printf("Enter b: \n");
    float b;
    scanf("%f", &b);
    printf("Enter c: \n");
    float c;
    scanf("%f", &c);
    quadraticEquation(a,b,c);
  }
  mainLoop();
}