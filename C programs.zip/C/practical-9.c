#include<stdio.h>
#include<string.h>
#include<stdlib.h>

//Holly Walker C3021739 (230217397)

//createArray function : gets input from the user, stores it into an array and returns the array
int* createArray(int size) {
    int* arr = calloc(size, sizeof(int));
    for (int i = 0; i < size; ++i) {
        printf("Enter an integer: \n");
        int x;
        scanf("%i", &x);
        arr[i] = x;
    }
    return arr;
}

//arraySearch function : searches through array for an element, and then prints it and it's position in the array
void arraySearch(int* arr1, int arrSize1, int* arr2, int arrSize2, int element) {
    //Searches through array 1
    for (int i = 0; i < arrSize1; ++i) {
        if (arr1[i] == element) {
            printf("\n%i was found in array 1 at postion %i",element,(i + 1));
        }
    }
    //Searches through array 2
    for (int i = 0; i < arrSize2; ++i) {
        if (arr2[i] == element) {
            printf("\n%i was found in array 2 at postion %i",element,(i + 1));
        }
    }
}

//printArraySum function : adds the elements in two arrays together and prints the results
void printArraySum(int* arr1, int arrSize1, int* arr2, int arrSize2) {
    //If array 1 is larger, the size of the result array will be the size of array 1
    if (arrSize1>arrSize2) {
        int* arr = calloc(arrSize1, sizeof(arr[0]));
        for (int i = 0; i < arrSize1; ++i) {
            //If theres no more elements from array 2 left, the rest of the elements from array 1 are added
            if (i>arrSize2) {
                arr[i] = arr1[i];
            }
            //The elements at position i from array 1 and 2 are added together and stored in the result array
            else {
                arr[i] = arr1[i] + arr2[i];
            }
        }
        //Prints the result array
        printf("Array sum[%i] = {",arrSize1);
        for (int i = 0; i < arrSize1; i++)
        {
            if(i == (arrSize1-1)) {
                printf("%i", arr[i]);
            }
            else {
                printf("%i,", arr[i]);
            }
        }
        printf("}\n\n");
    }
    //If array 2 is larger, the size of the result array will be the size of array 2
    else {
        int* arr = calloc(arrSize2, sizeof(int));
        for (int i = 0; i < arrSize2; ++i) {
            //If theres no more elements from array 1 left, the rest of the elements from array 2 are added
            if (i>arrSize1) {
                arr[i] = arr2[i];
            }
            //The elements at position i from array 1 and 2 are added together and stored in the result array
            else {
                arr[i] = arr1[i] + arr2[i];
            }
        }
        //Prints the result array
        printf("Array sum[%i] = {",arrSize2);
        for (int i = 0; i < arrSize2; i++)
        {
            if(i == (arrSize2-1)) {
                printf("%i", arr[i]);
            }
            else {
                printf("%i,", arr[i]);
            }
        }
        printf("}\n\n");
    }
}


//Main program
void main( int argc, char *argv[] ) {
    //Takes size of array 1, then calls createArray function
    printf("Enter the size of array 1: \n");
    int arrSize1;
    scanf("%i", &arrSize1);
    int* array1 = createArray(arrSize1);
    printf("\nIntegers for array 1 have been entered\n\n");

    //Takes size of array 2, then calls createArray function
    printf("Enter the size of array 2: \n");
    int arrSize2;
    scanf("%i", &arrSize2);
    int* array2 = createArray(arrSize2);
    printf("\nIntegers for array 2 have been entered\n\n");

    printf("-----------------------------------\n");

    //Prompts user to choose between option a or b
    printf("Input 'a' if you'd like to complete operation a, or 'b' for operation b\n");
    char operation[2];
    scanf("%s", &operation);

    //If a is inputted, the printArraySum function is called
    if(!(strcmp(operation,"a"))) {
        printArraySum(array1, arrSize1, array2, arrSize2);
    }
    else {
        //If b is inputted, the printArraySum function is called
        if (!(strcmp(operation,"b"))) {
            printf("Enter the element to be searched for: \n");
            int element;
            scanf("%i", &element);
            arraySearch(array1,arrSize1,array2,arrSize2,element);
        }
        //If something other than a or b is inputted, an error message appears
        else {
            printf("Invalid input: must be either 'a' or 'b'");
        }
    }
}