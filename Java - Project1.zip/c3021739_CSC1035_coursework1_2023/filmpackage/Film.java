package filmpackage;

/** Class Film to allow for creation of Film objects.
 * Methods include: getTitle, getEarnings, getReleaseDate, getLength, getGenre and toString.
 * Attributes include: title, releaseDate, earnings, length and genre.
 */
public class Film {
    private String title;
    private int releaseDate;
    private double earnings;
    private int length;
    private String genre;

    /*** Class constructor to allow for objects to be created
     *
     * @param title This is the title of the film.
     * @param releaseDate This is the year the film was released.
     * @param earnings This is the box office earnings in pounds.
     * @param length This is the length of the film in minutes.
     * @param genre This is the genre of the film
     */
    public Film(String title, int releaseDate, double earnings, int length, String genre) {
        //Makes sure that the year isn't negative
        if (releaseDate < 0){
            throw new IllegalArgumentException("Release date cannot be negative");
        }
        //Makes sure that the release date is not in the future
        if (releaseDate > 2024){
            throw new IllegalArgumentException("Release date cannot be in the future");
        }
        //Makes sure that earnings aren't negative
        if (earnings < 0){
            throw new IllegalArgumentException("Earnings cannot be negative");
        }
        //Makes sure that the length isn't negative
        if (length < 0){
            throw new IllegalArgumentException("filmpackage.Film length cannot be negative");
        }
        //Makes sure that the film's genre is only one of the three supported options.
        if (genre.equals("comedy") || genre.equals("horror") || genre.equals("action")) {
            this.releaseDate = releaseDate;
            this.title = title;
            this.earnings = earnings;
            this.length = length;
            this.genre = genre;
        }
        else{
            throw new IllegalArgumentException("Genre can only be comedy, horror or action");
        }
    }

    /*** Getter method for the film title
     *
     * @return Returns the title of the film as a string.
     */
    public String getTitle() {
        return title;
    }
    /*** Getter method for the film box office earnings
     *
     * @return Returns the earnings of the film as a double.
     */
    public double getEarnings() {
        return earnings;
    }
    /*** Getter method for the film release date
     *
     * @return Returns the release date of the film as an integer.
     */
    public int getReleaseDate() {
        return releaseDate;
    }
    /*** Getter method for the film length in minutes
     *
     * @return Returns the length of the film as an integer.
     */
    public int getLength() {
        return length;
    }
    /*** Getter method for the film genre
     *
     * @return Returns the genre of the film as a string.
     */
    public String getGenre() {
        return genre;
    }

    /*** toString method to represent the film object in an easy-to-read format
     *
     * @return This returns the values of the variables held in the class alongside the variable names.
     */
    @Override
    public String toString() {
        return "Film{" +
                "title='" + title + '\'' +
                ", releaseDate=" + releaseDate +
                ", earnings=" + earnings +
                ", length=" + length +
                ", genre='" + genre + '\'' +
                '}';
    }
}
