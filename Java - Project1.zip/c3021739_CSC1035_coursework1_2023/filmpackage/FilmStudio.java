package filmpackage;

import java.util.ArrayList;
import java.util.List;

/** Class FilmStudio to allow for creation of FilmStudio objects.
 * Methods include: getAverage, getFilmsByPerformance, getLongestFilm, addFilm, getStudioName, getFilms and toString.
 * Attributes include: films, studioName and longestFilm.
 */
public class FilmStudio {
    private List<Film> films;
    private String studioName;
    private Film longestFilm;

    /*** This is the class's constructor to allow for objects to be created.
     *
     * @param studioName This is the name of the studio.
     */
    public FilmStudio(String studioName) {
        this.films = new ArrayList<Film>();
        this.studioName = studioName;
        this.longestFilm = null;
    }

    /*** This gets the average box office earnings from the studio's films
     *
     * @param year This is the year collected from the users input.
     * @return Returns the average box office earnings as a double.
     */
    public double getAverage(int year) {
        double earnings = 0;
        int filmCount = 0;
        //For loop runs through every film in the studio and adds to the total (earnings) and increments filmCount
        for (int i = 0 ; i < this.films.size() ; i++) {
            if (films.get(i).getReleaseDate() == year) {
                earnings += films.get(i).getEarnings();
                filmCount += 1;
            }
        }
        //If earnings are 0, that means that no films exist in the studio therefore an exception needs to be rose
        if (earnings == 0) {
            throw new IllegalArgumentException("No films with this release date exist in the studio");
        }
        //Earnings divided by filmCount produce the mean of the studio's earnings (i.e. the average)
        return(earnings / filmCount);
    }

    /*** This is a method to return a list of films which have earnings less than the passed in upperLimit.
     *
     * @param upperLimit This is the amount that the film's earnings to be returned should be less than.
     * @return Returns a list of films with earnings below the passed in upperLimit.
     */
    public List<Film> getFilmsByPerformance(double upperLimit) {
        List<Film> filmsByPerformance = new ArrayList<Film>();
        //For each film in the studio, if the earnings are less than the upperLimit, they are added to the list to be returned
        for (int i = 0 ; i < this.films.size() ; i++) {
            if (films.get(i).getEarnings() < upperLimit) {
                filmsByPerformance.add(films.get(i));
            }
        }
        return filmsByPerformance;
    }

    /*** This is a getter for the longestFilm attribute.
     *
     * @return This returns the value held in longestFilm of type Film.
     */
    public Film getLongestFilm() {
        return longestFilm;
    }

    /*** This method allows a film to be added to the film studio while updating the longestFilm if needed.
     *
     * @param film This is the film that needs to be added to the studio.
     */
    public void addFilm(Film film) {
        this.films.add(film);
        //If longestFilm currently holds a value, it must be compared to the length of the film and updated if needed.
        if (this.longestFilm != null) {
            if (film.getLength() > this.longestFilm.getLength()) {
                this.longestFilm = film;
            }
        } //If longestFilm doesn't hold a value, it is updated with the passed in film.
        else {
            this.longestFilm = film;
        }
    }

    /*** This is a getter for the studioName attribute.
     *
     * @return Returns the studio's name as a string.
     */
    public String getStudioName() {
        return studioName;
    }
    /*** This is a getter for the films attribute.
     *
     * @return Returns the studio's films as a list of Film objects.
     */
    public List<Film> getFilms() {
        return films;
    }

    /*** toString method to represent the film studio object in an easy-to-read format
     *
     * @return This returns the values of the variables held in the class alongside the variable names.
     */
    @Override
    public String toString() {
        return "FilmStudio{" +
                "films=" + films +
                ", studioName='" + studioName + '\'' +
                ", longestFilm=" + longestFilm +
                '}';
    }
}
