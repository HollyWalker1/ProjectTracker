package filmpackage;

import java.util.ArrayList;
import java.util.List;

/** Class Reporting to allow for creation of Reporting objects.
 * Methods include: addStudio, getFilmStudios, getStudio, getFilms, getLongestFilm, getLargestAverage, getFilmsByPerformance and toString.
 * Attributes include: filmStudios and longestFilm.
 */
public class Reporting {
    private List<FilmStudio> filmStudios;
    private Film longestFilm;

    /*** Class constructor to allow for objects to be created
     *
     */
    public Reporting() {
        this.filmStudios = new ArrayList<FilmStudio>();
        this.longestFilm = null;
    }
    /*** This method allows a film studio to be added to the reporting object.
     *
     * @param studio This is the film studio that needs to be added to the reporting object.
     */
    public void addStudio(FilmStudio studio) {
        this.filmStudios.add(studio);
    }

    /*** This is a getter which returns the list of film studios.
     *
     * @return Returns the filmStudios list of type FilmStudio.
     */
    public List<FilmStudio> getFilmStudios() {
        return filmStudios;
    }

    /*** This is a getter which returns the details of a specified film studio.
     *
     * @param studioName This is the name of the studio (as a string) which needs to be looked up.
     * @return Returns the details of the film studio as a FilmStudio object if it exists in the filmStudios attribute.
     */
    public FilmStudio getStudio(String studioName) {
        //Each film studio in the filmStudios list is checked to see if it's name matches the passed in name
        for (int i = 0 ; i < this.filmStudios.size() ; i++) {
            //If there's a match, the film studio's details are returned to the user
            if (filmStudios.get(i).getStudioName().equals(studioName)) {
                return filmStudios.get(i);
            }
        }
        //If the film studio doesn't exist in the list, it raises an exception
        throw new IllegalArgumentException("Film Studio doesn't exist");
    }

    /*** This is a method which returns the films of a film studio passed in.
     *
     * @param studioName This is the name of the studio (as a string) which will have its films returned.
     * @return Returns the list of films released by the studio.
     */
    public List<Film> getFilms(String studioName) {
        List<Film> films = new ArrayList<Film>();
        //Each film studio in the filmStudios list is compared to the passed in studioName
        for (int i = 0 ; i < this.filmStudios.size() ; i++) {
            //If there's a match, the films of the studio are stored in the local variable films before ending the for loop.
            if (filmStudios.get(i).getStudioName().equals(studioName)){
                films = filmStudios.get(i).getFilms();
                break;
            }
        }
        //This returns the list of films by the studio, if the studio has no films then this will return an empty list
        // this will indicate that there aren't any films in the film studio
        return films;
    }

    /*** This is a method which calculates the longest film across all film studios and returns it.
     *
     * @return This returns the longest film held in the Reporting object as type Film.
     */
    public Film getLongestFilm() {
        //Each film studio's longest film is checked to see if it's longer than the length of the film held in longestFilm.
        for (int i = 0 ; i < this.filmStudios.size() ; i++) {
            if (this.longestFilm != null) {
                if (filmStudios.get(i).getLongestFilm().getLength() > this.longestFilm.getLength()) {
                    this.longestFilm = filmStudios.get(i).getLongestFilm();
                }
            } //If longestFilm is null, the longestFilm is automatically set to the longestFilm of the film studio.
            else {
                this.longestFilm = filmStudios.get(i).getLongestFilm();
            }
        }
        //If longest film is still null, that means no films have been recorded yet, therefore an exception is raised
        if (longestFilm == null) {
            throw new IllegalArgumentException("There are currently no films recorded yet");
        }
        return longestFilm;
    }

    /*** This method calculates the studio with the largest average box office earnings in a specified year.
     *
     * @param year This is the year passed in, only films released in this year will be used to calculate the highest average.
     * @return Returns the studio (of type FilmStudio) with the largest average in that particular year.
     */
    public String getLargestAverage(int year) {
        //If no film studios have been stored, there cannot be a largest average, therefore throwing an exception
        if (filmStudios.isEmpty()) {
            throw new IllegalArgumentException("No film studios have been stored yet");
        }
        double largestAverage = 0;
        FilmStudio studio = null;
        //Each film studio in filmStudios is compared to the value held in largestAverage
        for (int i = 0 ; i < this.filmStudios.size() ; i++) {
            //If the film studio has a higher average, the largestAverage variable is set the new highest average
            // and the studio variable is set to the film studio.
            if (filmStudios.get(i).getAverage(year) > largestAverage) {
                largestAverage = filmStudios.get(i).getAverage(year);
                studio = filmStudios.get(i);
            }
        }
        return studio.getStudioName();
    }

    /*** This method returns a list of films that are below a specified earning's threshold.
     *
     * @param upperLimit This is the threshold that all returned films must have earning's less than.
     * @return Returns a list of type Film of all the films below the threshold.
     */
    public List<Film> getFilmsByPerformance(double upperLimit) {
        List<Film> filmsByPerformance = new ArrayList<Film>();
        //Every film studio in filmStudios is checked to see if they have films that are below the threshold
        // if there are, they are added to the list filmsByPerformance
        for (int i = 0 ; i < this.filmStudios.size() ; i++) {
            filmsByPerformance.addAll(filmStudios.get(i).getFilmsByPerformance(upperLimit));
        }
        return filmsByPerformance;
    }
    /*** toString method to represent the Reporting object in an easy-to-read format
     *
     * @return This returns the values of the variables held in the class alongside the variable names.
     */
    @Override
    public String toString() {
        return "Reporting{" +
                "filmStudios=" + filmStudios +
                ", longestFilm=" + longestFilm +
                '}';
    }
}
