package filmpackage;

import java.util.InputMismatchException;
import java.util.Scanner;

/** Class ReportingIO to provide a menu system for the user and ability to manipulate data within a Reporting class.
 */
public class ReportingIO {
    /*** This main method presents a menu, the user will be able to input various things
     */
    public static void main(String[] args) {
        //This is the exit condition for the while loop
        boolean exit = false;
        //This creates a Reporting object to allow the user to create studios and films within.
        Reporting studioReporting = new Reporting();
        Scanner inputScanner = new Scanner(System.in);
        //Loops until the user chooses to exit from the program by inputting the number 8
        while (!exit) {

            //This presents a menu to the user with 8 options, the number is the input the user must type to choose the option
            System.out.println("\nenter film studio data (1)" + "\nenter film data (2)" + "\nlist all film studios (3)" + "\nlist all films made by a given film studio(4)" + "\nprovide reporting statistics on:\n film studio with the largest average box office earnings in a given year(5),\n longest film ever made (including all its details)(6),\n and all films made with box office earnings less than a given amount (including all their details(7))" + "\nexit(8)");
            String input = inputScanner.next();

            //This is for "enter film studio data"
            if (input.equals("1")) {
                //This allows the user to enter a title for the film studio
                try{
                    System.out.println("enter film studio name");
                    String input1 = inputScanner.next();
                    studioReporting.addStudio(new FilmStudio(input1));
                } //This prevents the program from crashing if an error occurs
                catch (Exception e){
                    System.out.println("An error has occurred, please try again");
                }
            } //This is for "enter film data"
            else if (input.equals("2")) {
                //This allows the user to input film details, if there's an error in what the user inputted it will
                // print an error message after inputting the details telling them what went wrong
                try {
                    System.out.println("enter film studio to add film data to");
                    String input1 = inputScanner.next();
                    System.out.println("enter film title");
                    String title = inputScanner.next();
                    System.out.println("enter film release year (must be an integer before 2025)");
                    int releaseDate = Integer.parseInt(inputScanner.next());
                    System.out.println("enter film earnings in pounds (cannot be negative)");
                    double earnings = Double.parseDouble(inputScanner.next());
                    System.out.println("enter film length in minutes (enter as an integer, cannot be negative)");
                    int length = Integer.parseInt(inputScanner.next());
                    System.out.println("enter film genre (can only be horror, comedy or action)");
                    String genre = inputScanner.next();
                    studioReporting.getStudio(input1).addFilm(new Film(title, releaseDate , earnings, length, genre));
                } //This prevents the program from crashing if an error occurs
                catch (IllegalArgumentException | InputMismatchException e){
                    System.out.println(e);
                } catch (Exception e) {
                    System.out.println("Another error occurred");
                }
            } //This is for "list all film studios"
            else if (input.equals("3")) {
                System.out.println(studioReporting.getFilmStudios());
            } //This is for "list all films made by a given film studio"
            else if (input.equals("4")) {
                try{
                    System.out.println("enter film studio name");
                    String input1 = inputScanner.next();
                    System.out.println(studioReporting.getStudio(input1).getFilms());
                } //This prevents the program from crashing if an error occurs
                catch (IllegalArgumentException | InputMismatchException e){
                    System.out.println(e);
                } catch (Exception e) {
                    System.out.println("Another error occurred");
                }
            } //This is for the "film studio with the largest average box office earnings in a given year"
            else if (input.equals("5")) {
                try {
                    System.out.println("enter year");
                    int input1 = Integer.parseInt(inputScanner.next());
                    System.out.println(studioReporting.getLargestAverage(input1));
                } //This prevents the program from crashing if an error occurs
                catch (InputMismatchException e){
                    System.out.println(e);
                } catch (Exception e) {
                    System.out.println("Another error occurred");
                }
            } //This is for "longest film ever made (including all its details)"
            else if (input.equals("6")) {
                System.out.println(studioReporting.getLongestFilm());
            } //This is for "all films made with box office earnings less than a given amount (including all their details"
            else if (input.equals("7")) {
                try {
                    System.out.println("enter the earnings that the films returned must be less than");
                    double input1 = Double.parseDouble(inputScanner.next());
                    System.out.println(studioReporting.getFilmsByPerformance(input1));
                } //This prevents the program from crashing if an error occurs
                catch (InputMismatchException e){
                    System.out.println(e);
                } catch (Exception e) {
                    System.out.println("Another error occurred");
                }
            } //This is for "exit"
            else if (input.equals("8")){
                //This causes the program to end due to it breaking out of the while loop
                exit = true;
            } else {
                //If the user enters something other than the numbers 1-8, they will be asked to re-enter
                System.out.println("Invalid input, please re-enter");
            }
        }
    }
}
