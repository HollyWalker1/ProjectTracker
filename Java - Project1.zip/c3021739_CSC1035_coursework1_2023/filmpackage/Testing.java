package filmpackage;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

/** Class Testing to test individual methods in the classes and ensure they yield expected results.
 */
public class Testing {
    public static void main(String[] args) {
        Reporting studioReporting = new Reporting();
        studioReporting.addStudio(new FilmStudio("studio1"));
        studioReporting.addStudio(new FilmStudio("studio2"));

        // Test 1 : Testing that adding film studios is successful
        System.out.println("\nTest 1 expected: [FilmStudio{films=[], studioName='studio1', longestFilm=null}, FilmStudio{films=[], studioName='studio2', longestFilm=null}]");
        System.out.println("Test 1 result: " + studioReporting.getFilmStudios() + "\n");

        // Test 2.1 : Testing that adding a film to a film studio with valid data shows expected result
        try {
            studioReporting.getStudio("studio1").addFilm(new Film("Film1", 2020, 8004001.1, 90, "comedy"));
        } catch (Exception e) {
            //If this doesn't show up, that means Test 2.1 is successful
            System.out.println("An unexpected error has occurred: " + e);
        } // This checks that the film with title Film1 exists within the studio, therefore meaning the test is successful
        if (studioReporting.getStudio("studio1").getLongestFilm().getTitle().equals("Film1"))  {
            System.out.println("Test 2.1 is successful");
        }

        // Test 2.2 : Testing that adding a film with an invalid releaseDate (in the future) causes an exception to be raised
        try {
            studioReporting.getStudio("studio1").addFilm(new Film("Film2", 2025, 8004001.1, 90, "comedy"));
        } catch (IllegalArgumentException e) {
            System.out.println("Test 2.2 is successful");
        }

        // Test 2.3 : Testing that adding a film with an invalid earnings (negative) causes an exception to be raised
        try {
            studioReporting.getStudio("studio1").addFilm(new Film("Film2", 2020, -8004001.1, 90, "comedy"));
        } catch (IllegalArgumentException e) {
            System.out.println("Test 2.3 is successful");
        }

        // Test 2.4 : Testing that adding a film with an invalid length (negative) causes an exception to be raised
        try {
            studioReporting.getStudio("studio1").addFilm(new Film("Film2", 2020, 8004001.1, -90, "comedy"));
        } catch (IllegalArgumentException e) {
            System.out.println("Test 2.4 is successful");
        }

        // Test 2.5 : Testing that adding a film with an invalid genre (not comedy, horror or action) causes an exception to be raised
        try {
            studioReporting.getStudio("studio1").addFilm(new Film("Film2", 2020, 8004001.1, 90, "sci-fi"));
        } catch (IllegalArgumentException e) {
            System.out.println("Test 2.5 is successful\n");
        }

        // Test 3 : Testing that getLongestFilm works for FilmStudio class
        try {
            //Previously the following film has been created : Film("Film1", 2020, 8004001.2, 90, "comedy"))
            studioReporting.getStudio("studio1").addFilm(new Film("Film2", 2020, 9005403.0, 100, "action"));
            //Film2 has length 100, whereas Film1 has length 90, therefore Film2 should be the longest film
            if (studioReporting.getStudio("studio1").getLongestFilm().getTitle().equals("Film2")) {
                System.out.println("Test 3 is successful \n");
            }
        } catch (Exception e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 4 : Testing that getAverage works for FilmStudio class
        try {
            double average1 = (8004001.1 + 9005403.0) / 2;
            double average2 = studioReporting.getStudio("studio1").getAverage(2020);
            if (average1 == average2) {
                System.out.println("Test 4 is successful\n");
            }
        } catch (Exception e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 5.1 : Testing that getFilmsByPerformance works for FilmStudio class
        try {
            //Studio 1 has two films, both below 10000000.0, therefore the size of getFilmsByPerformance should be 2
            if (studioReporting.getStudio("studio1").getFilmsByPerformance(10000000.0).size() == 2) {
                System.out.println("Test 5.1 is successful");
            }
        } catch (Exception e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 5.2 : (Continued)
        try {
            //Studio 1 has two films, only one is below 9000000.0, therefore the size of getFilmsByPerformance should be 1
            if (studioReporting.getStudio("studio1").getFilmsByPerformance(9000000.0).size() == 1) {
                System.out.println("Test 5.2 is successful");
            }
        } catch (Exception e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 5.3 : (Continued)
        try {
            //Studio 1 has two films,none are below 9000000.0, therefore getFilmsByPerformance should be empty
            if (studioReporting.getStudio("studio1").getFilmsByPerformance(8000000.0).isEmpty()) {
                System.out.println("Test 5.3 is successful\n");
            }
        } catch (Exception e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 6 : Testing getStudio throws an exception if the studio being requested doesn't exist
        try {
            studioReporting.getStudio("studio3");
        } catch (IllegalArgumentException e) {
            System.out.println("Test 6 is successful\n");
        }

        // Test 7 : Testing getFilms from the Reporting class
        System.out.println("Test 7 expected: " + "[Film{title='Film1', releaseDate=2020, earnings=8004001.1, length=90, genre='comedy'}, Film{title='Film2', releaseDate=2020, earnings=9005403.0, length=100, genre='action'}]");
        System.out.println("Test 7 result: " + studioReporting.getFilms("studio1") + "\n");

        // Test 8 : Testing Reporting class's getLongestFilm to ensure both studio's films are taken into account
        try {
            //Adds two films to studio2, the longest film in studio 1 has length 100, therefore Film3 with length 120 should be returned
            studioReporting.getStudio("studio2").addFilm(new Film("Film3", 2020, 6535001.1, 120, "action"));
            studioReporting.getStudio("studio2").addFilm(new Film("Film4", 2020, 8547548.72, 30, "horror"));
            if (studioReporting.getLongestFilm().getTitle().equals("Film3")) {
                System.out.println("Test 8 is successful");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("An unexpected error has occurred: " + e);
        }

        // Test 9 : Testing Reporting class's getLargestAverage
        try {
            //This should return studio1 since the average is 8504702.05, bigger than studio2's 7541274.9 for 2020
            studioReporting.getLargestAverage(2020);
            if (studioReporting.getLargestAverage(2020).equals("studio1")) {
                System.out.println("Test 9 is successful");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("An unexpected error has occurred: " + e);
        }
    }
}
