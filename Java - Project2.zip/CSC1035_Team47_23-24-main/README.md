# Quiz Application

This project is an interactive quiz taking system. That utilises databases of quiz question details and user details to generate information about the quizzes taken.
within the src package is the MainUserInterface class which displays all information to users and is interacted with through the use of a user interface.

## Features of Quiz application:

- Create new users
- Load users
- Save users
- Create questions
- Load questions
- Save questions
- Take a quiz
- Re-attempt a quiz
- View users quiz log
- Revise using incorrectly answered or previously unseen questions
- Determine if a user passes or fails a quiz

## How to use the Quiz Application
To use the quiz application, open the file, run the MainUserInterface class and follow the onscreen instructions.

## How to use multi-user functionality
To user the multi-user functionality, there are two ways, first you can open the file and run the UserLog.java and follow
the instructions, the other way is to run the MainUserInterface.java.

## Database

There's a questions.csv file still in the database repository solely for use in TestQuestions. And users.csv, to storage
username, the questions the user have done and the correctness of questions and so on.
