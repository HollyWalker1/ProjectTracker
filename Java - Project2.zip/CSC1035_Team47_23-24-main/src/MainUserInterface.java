import src.User;
import src.Questions;
import src.Quiz;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.lang.IllegalArgumentException;


/**
 *  Class that creates a user interface to allow the user to interact with the application
 */
public class MainUserInterface {
    // private static ArrayList<User> users = new ArrayList<>();

    /**
     * Displays a menu and retrieves the inputted selection
     *
     * @param myScanner The scanner object used for user input
     * @return Returns the user input (initially set to 0 to avoid an error if an invalid input is returned)
     */
    public static int menu(Scanner myScanner) {
        int input = 0;
        System.out.println("Please select one of the following option by inputting the corresponding number");
        System.out.println("1. View options related to users");
        System.out.println("2. View options related to questions");
        System.out.println("3. View options related to quizzes");
        System.out.println("4. Exit");
        try {
            input = myScanner.nextInt();
            return input;
        } catch (InputMismatchException e) { // if an invalid input is given prompts the user to try again
            System.out.println("Input must be an integer please try again");
            myScanner.nextLine();
        }
        return input;
    }

    /**
     * Displays a sub menu for options related to the users and retrieves user input
     *
     * @param myscanner Scanner object used for user input
     * @return Returns the user input (initially set to 0 to avoid an error if an invalid input is returned)
     */
    public static int subUserMenu(Scanner myscanner) {
        int input = 0;
        System.out.println("1. Create a new user");
        System.out.println("2. Load users from a file");
        System.out.println("3. Back to main menu");
        try {
            input = myscanner.nextInt();
            return input;
        } catch (
                InputMismatchException e) { // if the user inputs an invalid input such as a string the user is prompted to try again
            System.out.println("Input must be an integer please try again");
            myscanner.nextLine();
        }
        return input;
    }

    /**
     * Displays a sub menu for options related to questions and retrieves user input
     *
     * @param myscanner Scanner object used for user input
     * @return Returns the user input (initially set to 0 to avoid an error if an invalid input is returned)
     */
    public static int subQuestionMenu(Scanner myscanner) {
        int input = 0;
        System.out.println("1. Create a question");
        System.out.println("2. Load questions from a file");
        System.out.println("3. Save questions to a file");
        System.out.println("4. Back to main menu");
        try {
            input = myscanner.nextInt();
            return input;
        } catch (
                InputMismatchException e) { // if the user inputs an invalid input such as a string the user is prompted to try again
            System.out.println("Input must be an integer please try again");
            myscanner.nextLine();
        }
        return input;
    }

    /**
     * Displays a sub menu for options related to quizzes and retrieves user input
     *
     * @param myscanner Scanner object used for user input
     * @return Returns the user input (initially set to 0 to avoid an error if an invalid input is returned)
     */
    public static int subQuizMenu(Scanner myscanner) {
        int input = 0;
        System.out.println("1. Take a quiz");
        System.out.println("2. Retake a quiz");
        System.out.println("3. View a users log of quizzes");
        System.out.println("4. Back to main menu");
        try {
            input = myscanner.nextInt();
            return input;
        } catch (
                InputMismatchException e) { // if the user inputs an invalid input such as a string the user is prompted to try again
            System.out.println("Input must be an integer please try again");
            myscanner.nextLine();
        }
        return input;
    }


    /**
     * Takes in user input and then creates a new question using the provided input
     *
     * @param myscanner The scanner object used to get user input
     * @param questions The questions object which contains the method to add a question and a list of questions
     */
    public static void newQuestion(Scanner myscanner, Questions questions) {
        String question;
        String answer;
        String type;

        try {
            System.out.println("What is the question e.g. What is 5 + 2");
            myscanner.nextLine();
            question = myscanner.next();
            myscanner.nextLine();

            System.out.println("What is the answer to the question e.g. 7");
            answer = myscanner.next();
            myscanner.nextLine();

            System.out.println("What is the question type e.g. single");
            type = myscanner.next();
            myscanner.nextLine();

            questions.addQuestion(question, answer, type);
        } catch (IllegalArgumentException e) { // uses a try catch so that any user error will be reported to the user with a suggestion of what might have gone wrong
            System.out.println("One of inputs was not a string please try again and type must be single or multiple, if it is a multiple the answer must have a / to seperate each answer");
        }
    }

    /**
     * Takes in a filepath from the user and then tries to load files from the given file, asking the user to try again if the filepath given isn't valid
     *
     * @param myscanner Scanner object used to retrieve the user input
     * @param questions The questions object which contains the method to load questions from a file and a list of questions
     */
    public static void loadQuestions(Scanner myscanner, Questions questions) {
        String filepath;
        myscanner.nextLine();
        System.out.println("What is the filepath you would like to load the questions from?");
        filepath = myscanner.next();
        myscanner.nextLine();

        try {
            questions.loadDatabase(filepath);
        } catch (IOException e) { // if an invalid file path is inputted displays an error to the user
            System.out.println("Invalid file path please try again");
        }
    }

    /**
     * Takes a file name from the user and then saves the current list of questions to a csv file with the given name
     *
     * @param myscanner Scanner object used to retrieve the user input
     * @param questions The questions object which contains the method to save questions to a file and a list of questions
     */
    public static void saveQuestions(Scanner myscanner, Questions questions) {
        String file;
        myscanner.nextLine();
        System.out.println("What would you like to save the file as?");
        file = myscanner.next();
        myscanner.nextLine();

        try {
            questions.saveDatabase(file);
        } catch (IllegalArgumentException | IOException e) { // uses a method from the questions class to save the questions and displays an error if the user attempts to save the file as anything other than a csv
            System.out.println("File must end in .csv please try again");
        }
    }


    /**
     * Takes in user input and then creates a new user with the given input as the username and add it to a list of users
     *
     * @param myscanner The Scanner object used to take in user input
     * @param userList The list of users that the user will be added to
     */
    public static void newUser(Scanner myscanner, List<User> userList) {
        String newUserName;
        System.out.println("Please enter the username for the new user you'd like to create:");
        newUserName = myscanner.next();
        try {
            User currentUser = new User(newUserName);
            userList.add(currentUser); // adds the user to the current list of users
            System.out.println("User successfully created");
            User.saveAllUsers(userList, "database/users.txt"); // automatically saves the user to a csv file
        } catch (IllegalArgumentException e) { // if the username provided isn't valid it provides the user with the username restrictions
            System.out.println("Usernames can only be between 2-10 characters. Usernames must start with a capital letter and can only be letters, digits or the _ character. Please try again");
            myscanner.nextLine();
        }

    }


    /**
     * Loads users from a filepath given by the user
     *
     * @param myscanner The scanner object used to take in user input
     * @return Returns a list of users
     * @throws IOException Exception thrown incase the given filepath doesn't exist
     */
    public static List<User> loadUsers(Scanner myscanner) throws IOException {
        List<User> userList = new ArrayList<>();
        BufferedReader bufRead = null;
        String currentUser;

        System.out.println("What file would you like to read the users from? (such as database/users.txt)");
        String filepath = myscanner.next();

        try {
            bufRead = new BufferedReader(new FileReader(filepath)); // a buffered reader is used to iterate through the users
        } catch (FileNotFoundException e) { // let's the user know if the file they attempted to read from doesn't exist
            System.out.println("That file doesn't exist please try again");
        }

        bufRead.readLine(); // This skips the first line as it will always be blank due to how users are saved to the users.csv file

        while ((currentUser = bufRead.readLine()) != null) {
            userList.add(new User(currentUser)); // for each line of the given file it creates a user and adds that to a list of users
        }

        return userList; // returns a new list of users
    }


    /**
     * Allows the user to enter their username and then take a quiz
     *
     * @param myscanner The scanner object used to take in user input
     * @param questions The list of questions used in the quiz
     * @param userList The list of users used to find the corresponding user to the inputted username
     */
    public static void takeQuiz(Scanner myscanner, Questions questions, List<User> userList) {
        User currentUser = null;
        System.out.println("What is your username?");
        String userName = myscanner.next();

        for (User user : userList) {
            if (Objects.equals(user.getUsername(), userName)) { // loops through the list of users until the given user is found and prints out the user wasn't found
                currentUser = user;
            }
        }
        if (currentUser != null) {
            try {
                Quiz currentQuiz = new Quiz(questions, currentUser); // creates a new instance of the quiz class with the current user and list of questions
                currentQuiz.takeQuiz(); // gets the user to take a quiz and then generates the user log for that quiz
                currentQuiz.generateUserLogs();
                if (currentQuiz.quizPass()) { // if the user passes displays a congratulations messgae otherwise tells them they failed
                    System.out.println("Congratulations you passed the quiz!!!");
                } else {
                    System.out.println("You failed the quiz, please feel free to try again");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            System.out.println("That user doesn't exist please try again");
        }
    }


    /**
     * Allows the user to enter their username and then retake a quiz
     *
     * @param myscanner The scanner object used to take in input
     * @param questions The list of questions used in the quiz
     * @param userList The list of users used to find the corresponding user to the inputted username
     */
    public static void retakeQuiz(Scanner myscanner, Questions questions, List<User> userList) {
        User currentUser = null;
        System.out.println("What is your username?");
        String userName = myscanner.next();

        for (User user : userList) {
            if (Objects.equals(user.getUsername(), userName)) {
                currentUser = user;
            }
        }
        if (currentUser != null) {
            try {
                Quiz currentQuiz = new Quiz(questions, currentUser); // creates a new instance of the quiz class with the current user and list of questions
                currentQuiz.retakeQuiz(); // gets the user to retake a quiz
                currentQuiz.generateUserLogs(); // generates the user logs for the retaken quiz
                if (currentQuiz.quizPass()) { // displays if the user passed or failed
                    System.out.println("Congratulations you passed the quiz!!!");
                } else {
                    System.out.println("You failed the quiz, please feel free to try again");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            System.out.println("That user doesn't exist please try again");
        }
    }


    /**
     * Allows the user to view the log of that users most recently taken quiz
     *
     * @param myscanner The scanner object used to take in user input
     * @param questions The list of questions used in the quiz class
     * @param userList The list of users used to find the corresponding user to the inputted username
     * @throws IOException Thrown exception in case of runtime errors
     */
    public static void userQuizLog(Scanner myscanner, Questions questions, List<User> userList) throws IOException {
        User currentUser = null;
        System.out.println("What is your username?");
        String userName = myscanner.next();

        for (User user : userList) {
            if (Objects.equals(user.getUsername(), userName)) { // loops through the list of users to find the current user
                currentUser = user;
            }
        }
        if (currentUser != null) { // if the user is found it displays the user log of the most recent quiz taken
            Quiz currentQuiz = new Quiz(questions, currentUser);
            currentQuiz.getUsersQuizLog();
        } else {
            System.out.println("That user doesn't exist please try again");
        }
    }

    /**
     * Main method for MainUserInterface.java which calls the menu method and then runs the corresponding method depending on the user input
     *
     * @param args
     */
    public static void main(String[] args) throws IOException {
        Questions questions = new Questions(); // list of questions used throughout the code
        List<User> userList = new ArrayList<>(); // list of users used throughout the code

        Scanner myScanner = new Scanner(System.in); // Scanner object to take in user inut

        int userChoice;
        int userInput;
        do {
            userChoice = menu(myScanner); // takes the user interface and uses if and else if statements to run the appropriate sub menu
            if (userChoice == 1) {
                do {
                    userInput = subUserMenu(myScanner); // takes the users input and then sues if and else if statements to run the appropriate function
                    if (userInput == 1) {
                        newUser(myScanner, userList);
                    } else if (userInput == 2) {
                        userList.clear();
                        userList.addAll(loadUsers(myScanner));
                    }
                }
                while (userInput != 3); // goes back to the main menu if the user selects the option to go back
            }
            else if (userChoice == 2) {
                do {
                    userInput = subQuestionMenu(myScanner); // takes the users input and then uses if and else if statements to run the appropriate function
                    if (userInput == 1) {
                        newQuestion(myScanner, questions);
                    } else if (userInput == 2) {
                        loadQuestions(myScanner, questions);
                    } else if (userInput == 3) {
                        saveQuestions(myScanner, questions);
                    }
                }
                while (userInput != 4); // goes back to the main menu if the user selects the option to go back
            }
            else if (userChoice == 3) {
                do {
                    userInput = subQuizMenu(myScanner); // takes the users input and then uses if and else if statements to run the appropriate function
                    if (userInput == 1) {
                        takeQuiz(myScanner, questions, userList);
                    } else if (userInput == 2) {
                        retakeQuiz(myScanner, questions, userList);
                    } else if (userInput == 3) {
                        userQuizLog(myScanner, questions, userList);
                    }
                }
                while (userInput != 4) ; // goes back to the main menu if the user selects the option to go back
            }
        }
        while (userChoice != 4) ; // ends the loop and therefore exits the program when the user selects the option to exit
    }
}
