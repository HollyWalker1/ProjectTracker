package src;
import java.util.*;
import java.io.*;

/* CLASS METHODS QUICK SUMMARY:

 * addQuestion
 * getQuestion
 * checkQID
 * removeQuestion
 * modifyAnswer/Question/Type
 * checkType
 * getFullQuestionDetails
 * getAllQuestions
 * getQuestionIDs
 * getAnswer
 * getType
 * getQID
 * getQIDsByType
 * getQuestionsByType
 * loadDatabase
 * saveDatabase
 */

/** Class Questions for creation and manipulation of Question objects
 */
public class Questions {
    private ArrayList<ArrayList<String>> questions;
    private String database;
    private int QIDSize;

    /**
     * Constructor for class : Initialises the questions ArrayList
     */
    public Questions() {
        this.questions = new ArrayList<>();
    }

    /** addQuestions method : Allows for new questions to be added to the questions ArrayList
     *
     * @param question - String of the question
     * @param answer - String of the answer
     * @param type - String of the question type (only "single" or "multiple" is accepted)
     */
    public void addQuestion(String question, String answer, String type) {
        // Checks if the question is redundant (the exact same question already exists in the questions array)
        if (checkQuestion(question)) {
            throw new IllegalArgumentException("This question is already stored");
        }
        if (question.contains(",") || answer.contains(",")) {
            throw new IllegalArgumentException("Questions or answers should not have any commas in them");
        }
        String QID;
        // Loops for the amount of questions + 1 in the questions ArrayList
        // This ensures that a unique QID can be found in as few loops as possible without accidentally overriding already existing questions
        QID = "Q" + (this.QIDSize + 1);
        // Checks if a question already exists with this QID
        boolean checker = checkQID(QID);
        //If checkQID returns false, the question will be added with the current value held in QID
        if (!checker) {
            if (checkType(type, answer)) {
                ArrayList<String> questionData = new ArrayList<>();
                questionData.add(QID);
                questionData.add(question);
                questionData.add(answer);
                questionData.add(type);
                this.questions.add(questionData);
                this.QIDSize = this.QIDSize + 1;
            } else {
                // Exception thrown due to invalid type
                throw new IllegalArgumentException("Type must be single or multiple, if it is multiple, the answer must have a / to separate each answer, if it is single then / must not be used");
            }
        }
    }

    /** getQuestion method : Returns the question corresponding to a question ID
     *
     * @param QID - String of the question ID
     * @return - Returns a string of the question corresponding to the question ID passed in
     */
    public String getQuestion(String QID){
        for (int i = 0; i < this.questions.size(); i++) {
            if (this.questions.get(i).get(0).equals(QID)) {
                return this.questions.get(i).get(1);
            }
        }
        throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
    }

    /** getType method : Returns the type corresponding to a question ID
     *
     * @param QID - String of the question ID
     * @return - Returns a string of the type corresponding to the question ID passed in
     */
    public String getType(String QID){
        for (int i = 0; i < this.questions.size(); i++) {
            if (this.questions.get(i).get(0).equals(QID)) {
                return this.questions.get(i).get(3);
            }
        }
        throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
    }

    /** checkQID method : Checks if the question ID entered exists in the database
     *
     * @param QID - String of the question ID
     * @return - Returns boolean value depending on if the QID exists in the questions ArrayList
     */
    private boolean checkQID(String QID) {
        // Loops through questions array until it finds a match and then returns true
        for (int i = 0; i < this.questions.size(); i++) {
            if (this.questions.get(i).get(0).equals(QID)) {
                return true;
            }
        }
        // If no match is found, it returns false
        return false;
    }

    /** removeQuestion method : Removes the question associated with the question ID
     *
     * @param QID - String of the question ID
     */
    public void removeQuestion(String QID) {
        String questionID = null;
        // Loops through questions array until a match is found
        for (int i = 0; i < this.questions.size(); i++) {
            questionID = questions.get(i).get(0);
            if (questionID.equals(QID)) {
                // Removes the question's data from the array
                questions.remove(i);
                // Stops the loop early if a match is found
                break;
            }
        }
        if (questionID == null) {
            throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
        }
    }

    /** modifyAnswer method : Replaces the answer associated with a specified question ID
     *
     * @param QID - String of the question ID
     * @param answer - String of the answer
     */
    public void modifyAnswer(String QID, String answer) {
        if (!checkQID(QID)) {
            throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
        }
        if (answer.contains(",")) {
            throw new IllegalArgumentException("Answers should not have any commas in them");
        }
        // Loops through questions array until a question ID match is found
        for (int i = 0; i < this.questions.size(); i++) {
            String questionID = questions.get(i).get(0);
            String question = questions.get(i).get(1);
            String questionType = questions.get(i).get(3);
            if (questionID.equals(QID)) {
                // Removes the old question and adds the modified version of the question to the array
                if (checkType(questionType, answer)) {
                    questions.remove(i);
                    ArrayList<String> questionData = new ArrayList<>();
                    questionData.add(questionID);
                    questionData.add(question);
                    questionData.add(answer);
                    questionData.add(questionType);
                    questions.add(questionData);
                    // Stops the loop early once a valid match is found
                    break;
                } else {
                    // Exception thrown due to invalid type
                    throw new IllegalArgumentException("Type must be single or multiple, if it is multiple, the answer must have a / to separate each answer, if it is single then / must not be used");
                }
            }
        }
    }

    /** modifyQuestion method : Replaces the question associated with a specified question ID
     *
     * @param QID - String of the question ID
     * @param question - String of the question
     */
    public void modifyQuestion(String QID, String question) {
        if (!checkQID(QID)) {
            throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
        }
        if (checkQuestion(question)) {
            throw new IllegalArgumentException("This question is already stored");
        }
        if (question.contains(",")) {
            throw new IllegalArgumentException("Questions should not have any commas in them");
        }
        // Loops through questions array until a question ID match is found
        for (int i = 0; i < this.questions.size(); i++) {
            String questionID = questions.get(i).get(0);
            String answer = questions.get(i).get(2);
            String questionType = questions.get(i).get(3);
            if (questionID.equals(QID)) {
                // Removes the old question and adds the modified version of the question to the array
                questions.remove(i);
                ArrayList<String> questionData = new ArrayList<>();
                questionData.add(questionID);
                questionData.add(question);
                questionData.add(answer);
                questionData.add(questionType);
                questions.add(questionData);
                // Stops the loop early once a valid match is found
                break;
            }
        }
    }

    /** modifyType method : Replaces the type and answer associated with a specified question ID
     *
     * @param QID - String of the question ID
     * @param type - String of the question type - can only be "single" or "multiple"
     * @param answer - Sting of the question answer
     */
    public void modifyType(String QID, String type, String answer) {
        if (!checkQID(QID)) {
            throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
        }
        // Checks that the type is valid
        if (!checkType(type, answer)) {
            throw new IllegalArgumentException("Type must be single or multiple, if it is multiple, the answer must have a / to separate each answer, if it is single then / must not be used");
        }
        if (answer.contains(",")) {
            throw new IllegalArgumentException("Answers should not have any commas in them");
        }
        // Loops through questions array until a question ID match is found
        for (int i = 0; i < this.questions.size(); i++) {
            String questionID = questions.get(i).get(0);
            String question = questions.get(i).get(1);
            if (questionID.equals(QID)) {
                // Removes the old question and adds the modified version of the question to the array
                questions.remove(i);
                ArrayList<String> questionData = new ArrayList<>();
                questionData.add(questionID);
                questionData.add(question);
                questionData.add(answer);
                questionData.add(type);
                questions.add(questionData);
                // Stops the loop early once a valid match is found
                break;
            }
        }
    }

    /** checkType method : Checks that the type is valid (single or multiple) and makes sure the type matches the answer
     *
     * @param type - String of the question type - can only be "single" or "multiple"
     * @param answer - String of the question answer (if type is multiple, it should have at least one / in it)
     * @return - Returns boolean value, true if the type is valid and matches the answer, false if not
     */
    private boolean checkType(String type,String answer) {
        //returns true if the answer has at least one / in it
        if (type.equals("multiple")) {
            return answer.contains("/");
        }
        //returns true if the answer doesn't have a / in i
        else if (type.equals("single")) {
            return !answer.contains("/");
        }
        //returns false if type is not "multiple" or "single"
        return false;
    }

    /** checkQuestion method : Checks if the question is already stored in the questions array
     *
     * @param question - String of the question
     * @return - Returns boolean value, it will be true if the question already exists in the questions array
     */
    private boolean checkQuestion(String question) {
        // If the question is already stored in the questions array, it will return true
        for (int i = 0; i < this.questions.size(); i++) {
            if (this.questions.get(i).get(1).equals(question)) {
                return true;
            }
        }
        // returns false if the question doesn't already exist in the array
        return false;
    }

    /** getFullQuestionDetails method : Retrieves the full details of all questions stored in the questions array
     *
     * @return - Returns full ArrayList for questions
     */
    public ArrayList<ArrayList<String>> getFullQuestionDetails() {
        return questions;
    }

    /** getAllQuestions method : Retrieves just the question for all questions in the questions array
     *
     * @return - Returns an ArrayList of just the questions held in the questions array
     */
    public ArrayList<String> getAllQuestions() {
        // creates local array questions
        ArrayList<String> questions = new ArrayList<>();
        // adds each question to the local array
        for (int i = 0; i < this.questions.size(); i++) {
            questions.add(this.questions.get(i).get(1));
        }
        // returns the local array
        return questions;
    }

    /** getQuestionIDs method : Returns all question IDs in the questions array
     *
     * @return - Returns ArrayList of all question IDs held in the questions array
     */
    public ArrayList<String> getQuestionIDs() {
        ArrayList<String> questionIDs = new ArrayList<>();
        // Goes through all questions in the questions array and adds the IDs to the questionIDs array
        for (int i = 0; i < this.questions.size(); i++) {
            questionIDs.add(String.valueOf(this.questions.get(i).get(0)));
        }
        return questionIDs;
    }

    /** getAnswer method : Returns the answer that corresponds to a specified question ID
     *
     * @param QID - String of the question ID
     * @return - Returns the answer as a list
     * @throws Exception - Throws exception in case an unknown error occurs
     */
    public List<String> getAnswer(String QID) throws Exception {
        String type;
        String answer;
        //checks that a question with the QID exists
        if (checkQID(QID)) {
            ArrayList<String> answers = new ArrayList<>();
            for (int i = 0; i < this.questions.size(); i++) {
                String questionID = questions.get(i).get(0);
                // If the question ID's match
                if (questionID.equals(QID)) {
                    answer = questions.get(i).get(2);
                    type = questions.get(i).get(3);
                    // If the type is multiple, the answers will be split up by the /'s in middle of them and then added to the list
                    if (type.equals("multiple")) {
                        String[] individualAnswers = answer.split("/");
                        answers.addAll(Arrays.asList(individualAnswers));
                    }
                    // If the type is single, answers will be returned as a list with a single value in it
                    else {
                        answers.add(answer);
                    }
                    return answers;
                }
            }
        } else {
            // Exception thrown if a question with the specified question ID doesn't exist in the questions array
            throw new IllegalArgumentException("Question ID doesn't match the ID of any stored questions");
        }
        // Exception thrown if unexpected error occurs
        throw new Exception("Unexpected error occurred");
    }

    /** getQID method : Secondary index using question to find the question ID
     *
     * @param question - String of the question
     * @return - Returns the question ID corresponding to the question
     */
    public String getQID(String question) {
        for (int i = 0; i < this.questions.size(); i++) {
            String questionCheck = questions.get(i).get(1);
            if (questionCheck.equals(question)) {
                return questions.get(i).get(0);
            }
        }
        // Exception thrown if there isn't a match in the questions array
        throw new IllegalArgumentException("This question doesn't currently exist in the database");
    }

    /** getQIDsByType method : Returns an ArrayList of question IDs of a particular type
     *
     * @param type - String of type, either single or multiple
     * @return - Returns an array of question IDs of the specified type
     */
    public ArrayList<String> getQIDsByType(String type) {
        ArrayList<String> QIDs = new ArrayList<>();
        // Checks if the type is valid
        if (type.equals("single") || type.equals("multiple")) {
            for (int i = 0; i < this.questions.size(); i++) {
                // If the question is of the specified type, it is added to the local array
                if (questions.get(i).get(3).equals(type)) {
                    QIDs.add(questions.get(i).get(0));
                }
            }
        } else {
            // Exception thrown if the type is invalid
            throw new IllegalArgumentException("Type must be single or multiple");
        }
        return QIDs;
    }

    /** getQuestionsByType method : Returns an ArrayList of questions of a particular type
     *
     * @param type - String of type, either single or multiple
     * @return - Returns an array of questions of the specified type
     */
    public List<String> getQuestionsByType(String type) {
        ArrayList<String> questionArray = new ArrayList<>();
        // Checks if the type is valid
        if (type.equals("single") || type.equals("multiple")) {
            for (int i = 0; i < this.questions.size(); i++) {
                // If the question is of the specified type, it is added to the local array
                if (questions.get(i).get(3).equals(type)) {
                    questionArray.add(questions.get(i).get(1));
                }
            }
        } else {
            // Exception thrown for invalid type
            throw new IllegalArgumentException("Type must be single or multiple");
        }
        return questionArray;
    }

    /** loadDatabase method : Loads the database (csv file) by turning it into an array of arrays (each being an individual question and it's details)
     *
     * @param filePath - This is a string of the file path e.g. "database/questions.csv"
     * @throws IOException - Throws an exception if there is an invalid filePath
     */
    public void loadDatabase(String filePath) throws IOException {
        this.database = filePath.substring(9);
        // Scans through files and separates values by commas
        Scanner sc = new Scanner(new File(filePath));
        sc.useDelimiter(",");

        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = "";
        String splitBy = ",";

        // This skips the header as it would cause issues if it were saved into the array
        br.readLine();

        ArrayList<ArrayList<String>> questions = new ArrayList<>();
        // Reads through each line until it reaches an empty line
        while ((line = br.readLine()) != null) {
            this.QIDSize = this.QIDSize + 1;
            questions.add(new ArrayList<>(List.of(line.split(splitBy))));
        }
        this.questions = questions;
    }

    /** saveDatabase method : Saves the current contents of the questions array to a specified .csv file (if the file doesn't already exist, a new one will be created)
     *
     * @param file - String of the file e.g. "questions.csv"
     * @throws IOException - Throws exception if the file is invalid
     */
    public void saveDatabase(String file) throws IOException {
        // Checks that the file is a .csv file
        if (!file.endsWith(".csv")) {
            throw new IllegalArgumentException("File must end in .csv");
        }
        // Sets the filePath so that the file is saved in the database directory (to keep the folders organised)
        String filePath = "database/" + file;
        File csvFile = new File(filePath);
        FileWriter fileWriter = new FileWriter(csvFile);
        // Writes the header (fields) on the first line to make it easy to read
        fileWriter.write("QID,question,answer,type\n");
        // Writes the details of each question on a separate line
        for (ArrayList<String> question : this.questions) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < question.size(); i++) {
                line.append(question.get(i).replaceAll("",""));
                if (i != question.size() - 1) {
                    // Separates each value in the question by a comma
                    line.append(',');
                }
            }
            line.append("\n");
            fileWriter.write(line.toString());
        }
        fileWriter.close();
    }

    /** getDatabase method : Returns the database
     *
     * @return This returns the String name of the database
     */
    public String getDatabase() {
        return database;
    }

    /*
    public ArrayList<ArrayList<String>> getReviseQuestions(User user) {
        Map<String, Boolean> history = user.getQuestionHistory();
        ArrayList<ArrayList<String>> reviseQuestions = new ArrayList<>();

        for (ArrayList<String> question : this.questions) {
            String QID = question.get(0);
            // 如果用户没有回答过这个问题或者答案不正确
            if (!history.containsKey(QID) || !history.get(QID)) {
                reviseQuestions.add(question);
            }
        }
        return reviseQuestions;
    }
    */

    /** toString method : Returns a string representation of the questions class's contents
     *
     * @return - Returns the values held in the questions class in an easy-to-read format
     */
    @Override
    public String toString() {
        return "Questions{" +
                "questions=" + questions +
                ", database='" + database + '\'' +
                '}';
    }

    /** equals method : Checks if two objects of class Questions have identical values for both the questions array and database file
     *
     * @param o - This is another object from the Questions class
     * @return - Returns boolean value, it will be true if the questions array and database file are the same in both objects
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Questions questions1 = (Questions) o;
        return QIDSize == questions1.QIDSize && Objects.equals(questions, questions1.questions) && Objects.equals(database, questions1.database);
    }

    /** hashCode method : Allows for the equals method to work on hash based collections
     *
     * @return - Returns the integer value of the hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(questions, database, QIDSize);
    }
}