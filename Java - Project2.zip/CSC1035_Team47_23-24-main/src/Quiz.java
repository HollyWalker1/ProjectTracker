package src;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.io.*;
import java.io.File;
import java.util.Scanner;
import src.Questions;
import src.User;

/*** Quiz class : Allows the user to take a quiz and stores them in quiz user logs
 *
 */
public class Quiz {
    private Questions questions;
    private User user;
    private int questionPointer = 0;
    private int totalQuestionsAsked = 0;
    private List<String> correctAnswers = new ArrayList<>();
    private List<String> incorrectAnswers = new ArrayList<>();
    private List<String> givenAnswers = new ArrayList<>();
    private long timeTaken = 0;

    /*** Quiz constructor : Initialises the quiz object and saves the user and questions information
     *
     * @param questions - This is an object of class questions, it holds the questions and their matching answers
     * @param user - This is an object of class user, it holds the user information
     * @throws IOException - Throws exception if there's a file error in getSuccessfulQuestions
     */
    public Quiz(Questions questions, User user) throws IOException {
        this.questions = questions;
        this.user = user;
        getSuccessfulQuestions();
        if (!correctAnswers.isEmpty()) {
            this.totalQuestionsAsked += correctAnswers.size();
        }
        if (!incorrectAnswers.isEmpty()) {
            this.totalQuestionsAsked += incorrectAnswers.size();
        }
        if (!givenAnswers.isEmpty()) {
            questionPointer = givenAnswers.size();
        }
    }

    /*** getSuccessfulQuestions method : Loads the information from the userlog csv file
     *
     * @throws IOException - Throws exception if there's a file error
     */
    private void getSuccessfulQuestions() throws IOException {
        List<String> correctAnswers = new ArrayList<>();
        List<String> incorrectAnswers = new ArrayList<>();
        List<String> givenAnswers = new ArrayList<>();
        File csvFile = new File("database/Userlogs-" + this.questions.getDatabase());
        if (!csvFile.isFile()) {
            FileWriter fileWriter = new FileWriter(csvFile);
            fileWriter.write("User,Questions answered correctly,Questions answered incorrectly,Given answers\n");
            fileWriter.close();
        }
        Scanner sc = new Scanner(new File("database/Userlogs-" + this.questions.getDatabase()));
        sc.useDelimiter(",");
        BufferedReader br = new BufferedReader(new FileReader("database/Userlogs-" + this.questions.getDatabase()));
        String line = "";
        String splitBy = ",";
        // This skips the header as it would cause issues if it were saved into the array
        br.readLine();
        ArrayList<ArrayList<String>> quiz = new ArrayList<>();
        // Reads through each line until it reaches an empty line
        while ((line = br.readLine()) != null) {
            quiz.add(new ArrayList<>(List.of(line.split(splitBy))));
        }
        for (int i = 0; i < quiz.size(); i++) {
            String user = quiz.get(i).get(0);
            if (user.equals(this.user.getUsername())) {
                if (quiz.get(i).get(1).contains("/")) {
                    correctAnswers = List.of(quiz.get(i).get(1).split("/"));
                    this.correctAnswers.addAll(correctAnswers);
                } else {
                    correctAnswers.add(quiz.get(i).get(1));
                    this.correctAnswers.addAll(correctAnswers);
                }
                if (quiz.get(i).get(2).contains("/")) {
                    incorrectAnswers = List.of(quiz.get(i).get(2).split("/"));
                    this.incorrectAnswers.addAll(incorrectAnswers);
                } else {
                    incorrectAnswers.add(quiz.get(i).get(2));
                    this.incorrectAnswers.addAll(incorrectAnswers);
                }
                if (quiz.get(i).get(3).contains("/")) {
                    givenAnswers = List.of(quiz.get(i).get(3).split("/"));
                    this.givenAnswers.addAll(givenAnswers);
                } else {
                    givenAnswers.add(quiz.get(i).get(3));
                    this.givenAnswers.addAll(givenAnswers);
                }

            }
        }
    }

    /*** takeQuiz method : Allows the user to take a quiz and allows them to stop answering questions at any point
     *
     * @throws Exception - Throws an exception when the answerQuestion method is called if the answer contains a comma
     */
    public void takeQuiz() throws Exception {
        Scanner myScanner = new Scanner(System.in);
        long startTime = System.currentTimeMillis()/1000;
        int countAnswers = 0;
        while (true) {
            // If there's no more questions left in the quiz to answer, this is shown to the user
            if (this.questionPointer > (this.questions.getAllQuestions().size() - 1)) {
                System.out.println("You have reached the end of the questions in this quiz\n");
                long endTime = System.currentTimeMillis()/1000;
                this.timeTaken = (endTime - startTime);
                System.out.println("You answered " + countAnswers + " questions in " + (endTime - startTime) + " seconds");
                displayAnswers(countAnswers);
                System.out.println("The current overall percentage of questions answered correctly for this quiz is " + getPercentageCorrect() + "%");
                break;
            }
            int input = 0;
            System.out.println("Please select one of the following option by inputting the corresponding number");
            System.out.println("1. Answer next question");
            System.out.println("2. Exit");
            try {
                input = myScanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Input must be an integer please try again");
                myScanner.nextLine();
            }
            if (input == 1) {
                // Displays the question and allows the user to answer it
                String question = this.questions.getAllQuestions().get(this.questionPointer);
                System.out.println(question);
                String answer = myScanner.next();
                answerQuestion(answer);
                countAnswers +=1;
            } else if (input == 2) {
                // ouputs the quiz information (time taken, given vs correct answers alongside the percentage correct
                long endTime = System.currentTimeMillis()/1000;
                this.timeTaken = (endTime - startTime);
                System.out.println("You answered " + countAnswers + " questions in " + (endTime - startTime) + " seconds");
                displayAnswers(countAnswers);
                System.out.println("The current overall percentage of questions answered correctly for this quiz is " + getPercentageCorrect() + "%");
                break;
            }
        }
    }
    /*** answerQuestion method : Checks if the answer the user provides is correct
     *
     * @param answer - This is the answer inputted by the user
     * @throws Exception - Throws an exception if the answer contains a comma
     */
    public void answerQuestion(String answer) throws Exception {
        if (answer.contains(",")) {
            throw new IllegalArgumentException("Answers should not have any commas in them");
        }
        String QID = this.questions.getQID(this.questions.getAllQuestions().get(this.questionPointer));
        boolean checkAnswer = false;
        for (int i = 0; i < this.questions.getAnswer(QID).size(); i++) {
            // If the question is correct, it is added to correctAnswers and updates the pointer, given answers and total asked
            if (this.questions.getAnswer(QID).get(i).equals(answer)) {
                checkAnswer = true;
                this.questionPointer += 1;
                this.totalQuestionsAsked += 1;
                this.correctAnswers.add(QID);
                this.givenAnswers.add(answer);
            }
        }
        // if the question is incorrect, it is added to incorrectAnswers and updates the pointer, given answers and total asked
        if (!checkAnswer) {
            this.questionPointer += 1;
            this.totalQuestionsAsked += 1;
            this.incorrectAnswers.add(QID);
            this.givenAnswers.add(answer);
        }
    }

    /*** generateUserLogs method : Generates a csv file for the quiz, storing all the correctly answered questions, incorrectly answered questions, alongside the given answers
     *
     * @throws IOException - Throws exception if there's a file error (e.g. file doesn't exist)
     */
    public void generateUserLogs() throws IOException {
        // Sets the file name
        String file = "Userlogs-" + this.questions.getDatabase();
        String filePath = "database/" + file;
        File csvFile = new File(filePath);
        String correct = "";
        // turns the array list to a single string split by /
        for (int i = 0; i < this.correctAnswers.size(); i++) {
            correct += correctAnswers.get(i) + "/";
        }
        if (!correct.equals("")) {
            correct = correct.substring(0, correct.length() - 1);
        }
        String incorrect = "";
        // turns the array list to a single string split by /
        for (int i = 0; i < this.incorrectAnswers.size(); i++) {
            incorrect += incorrectAnswers.get(i) + "/";
        }
        if (!incorrect.equals("")) {
            incorrect = incorrect.substring(0, incorrect.length() - 1);
        }
        String answers = "";
        // turns the array list to a single string split by /
        for (int i = 0; i < this.givenAnswers.size(); i++) {
            answers += givenAnswers.get(i) + "/";
        }
        if (!answers.equals("")) {
            answers = answers.substring(0, answers.length() - 1);
        }
        // If the csv file for this quiz already exists, it is updated with the new information
        if (csvFile.isFile()) {
            FileWriter fileWriter = new FileWriter(csvFile, true);
            boolean checkData = false;
            List<String> data = Files.readAllLines(Path.of(filePath));
            for (String dataRead : data) {
                if (dataRead.contains(user.getUsername())) {
                    checkData = true;
                }
            }
            // if the user has data in the csv file, the data held there is updated
            if (checkData) {
                changeFile(filePath, user.getUsername(), correct, incorrect, answers);
            }
            // if the user doesn't already exist, they are added to the end of the file
            else {
                BufferedWriter writer = new BufferedWriter(fileWriter);
                writer.append(this.user.getUsername() + "," + correct + "," + incorrect + "," + answers);
                writer.close();
            }
        }
        // If the csv file for this quiz doesn't already exist, it creates a new file and adds the data to it
        else {
            FileWriter fileWriter = new FileWriter(csvFile);
            fileWriter.write("User,Questions answered correctly,Questions answered incorrectly,Given answers\n");
            fileWriter.write(this.user.getUsername() + "," + correct + "," + incorrect + "," + answers);
            fileWriter.close();
        }
    }

    /*** changeFile method : If a user already exists in the database, this will be called to change the data stored for them
     *
     * @param filePath - This is a string of the file path for the questions csv file
     * @param username - This is a string of the user's username
     * @param correct - This is a string of all correctly answered question's question IDs
     * @param incorrect - This is a string of all incorrectly answered question's question IDs
     * @param answers - This is a string of all given answers to all questions
     * @throws IOException - Throws exception if there's a file error (e.g. file doesn't exist)
     */
    private void changeFile(String filePath, String username, String correct, String incorrect,String answers) throws IOException {
        Scanner sc = new Scanner(new File(filePath));
        sc.useDelimiter(",");
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = "";
        String splitBy = ",";
        // This skips the header as it would cause issues if it were saved into the array
        br.readLine();
        ArrayList<ArrayList<String>> quiz = new ArrayList<>();
        // Reads through each line until it reaches an empty line
        while ((line = br.readLine()) != null) {
            quiz.add(new ArrayList<>(List.of(line.split(splitBy))));
        }
        for (int i = 0; i < quiz.size(); i++) {
            String user = quiz.get(i).get(0);
            if (user.equals(username)) {
                // Removes the users's data from the array
                quiz.remove(i);
                // Stops the loop early if a match is found
                break;
            }
        }
        // adds the user's new data to the array list
        ArrayList<String> userFile = new ArrayList<>();
        userFile.add(username);
        userFile.add(correct);
        userFile.add(incorrect);
        userFile.add(answers);
        quiz.add(userFile);
        // Replaces the data in the csv file with the data held in quiz
        File csvFile = new File(filePath);
        FileWriter fileWriter = new FileWriter(csvFile);
        // Writes the header (fields) on the first line to make it easy to read
        fileWriter.write("User,Questions answered correctly,Questions answered incorrectly,Given answers\n");
        // Writes the details of each user log on a separate line
        for (ArrayList<String> data : quiz) {
            StringBuilder line2 = new StringBuilder();
            for (int i = 0; i < data.size(); i++) {
                line2.append(data.get(i).replaceAll("",""));
                if (i != data.size() - 1) {
                    // Separates each value in the log by a comma
                    line2.append(',');
                }
            }
            line2.append("\n");
            fileWriter.write(line2.toString());
        }
        fileWriter.close();
    }

    /*** getCorrectlyAnsweredQuestionIDs method : Getter to return correctly answered question's question IDs
     *
     * @return - Returns a list of type string of correctly answered question's question IDs
     */
    public List<String> getCorrectlyAnsweredQuestionIDs() {
        return correctAnswers;
    }

    /*** getIncorrectlyAnsweredQuestionIDs method : Getter to return incorrectly answered question's question IDs
     *
     * @return - Returns a list of type string of incorrectly answered question's question IDs
     */
    public List<String> getIncorrectlyAnsweredQuestionIDs() {
        return incorrectAnswers;
    }

    /*** getGivenAnswers method : Getter to return the user's given answers
     *
     * @return - Returns a list of type string of the user's given answers
     */
    public List<String> getGivenAnswers() {
        return givenAnswers;
    }

    /*** getUncompletedQuestionIDs : Getter to return the question IDs of questions which have not yet been asked
     *
     * @return - Returns a list of type string of uncompleted question's question IDs
     */
    public List<String> getUncompletedQuestionIDs() {
        List<String> returnList = new ArrayList<>();
        returnList.addAll(this.questions.getQuestionIDs());
        List<String> allQuestions = new ArrayList<>();
        allQuestions.addAll(correctAnswers);
        allQuestions.addAll(incorrectAnswers);
        // adds questions IDs of questions that haven't been answered yet to returnList and then returns it to the user
        for (int i = 0; i < this.questions.getAllQuestions().size(); i++) {
            for (int j = 0; j < allQuestions.size(); j++) {
                if (allQuestions.get(j).equals(this.questions.getQuestionIDs().get(i))) {
                    returnList.remove(this.questions.getQuestionIDs().get(i));
                }
            }
        }
        return returnList;
    }

    /*** getPercentageCorrect Method : Getter to return the percentage of correctly answered questions
     *
     * @return - Returns percentage of correctly answered questions as a double
     */
    public double getPercentageCorrect(){
        double percentage = (double) this.correctAnswers.size() / (double)this.totalQuestionsAsked;
        percentage = percentage*(double)100;
        return percentage;
    }

    /*** retakeQuiz Method : Allows the user to clear all saved data and take the quiz again
     *
     * @throws Exception - Throws an exception when the answerQuestion method is called if the answer contains a comma
     */
    public void retakeQuiz() throws Exception {
        this.correctAnswers.clear();
        this.incorrectAnswers.clear();
        this.totalQuestionsAsked = 0;
        this.givenAnswers.clear();
        this.questionPointer = 0;
        takeQuiz();
    }

    /*** displayAnswers Method : Displays the given answers alongside the correct answers
     *
     * @param countAnswers - This will allow the method to show the last (countAnswers) answers that the user gave
     */
    public void displayAnswers(int countAnswers) throws Exception {
        for (int i = 0; i < this.givenAnswers.size(); i++) {
            int count = i + 1;
            System.out.println("Question " + count + ". The inputted answer was: " + this.givenAnswers.get(i) + ". The correct answer was : " + this.questions.getAnswer(this.questions.getQuestionIDs().get(i)));
        }
    }

    /*** quizPass Method : Checks if the user has passed the quiz (got higher than 40%)
     *
     * @return - Returns true if the user passed the quiz, false if the user failed
     */
    public boolean quizPass(){
        // gets percentage
        double percentage = getPercentageCorrect();
        // checks if the percentage is above 40%
        return percentage >= 40.0;
    }

    /*** getUsersQuizLog method : Returns a log of all the user's data stored in quiz
     *
     */
    public void getUsersQuizLog(){
        System.out.println("User : " + this.user.getUsername());
        System.out.println("The question IDs of the questions the user has answered correctly are : " + this.correctAnswers);
        System.out.println("The question IDs of the questions the user has answered incorrectly are : " + this.incorrectAnswers);
        System.out.println("The answers you have given are : " + this.givenAnswers);
        System.out.println("You have answered " + this.givenAnswers.size() + " questions");
    }

    /*** totalQuestionsAsked method : Getter for totalQuestionsAsked
     *
     * @return - Returns an integer of the total amount of questions the user has answered
     */
    public int totalQuestionsAsked() {
        return totalQuestionsAsked;
    }

    /*** questionPointer method : Getter for questionPointer
     *
     * @return - Returns an integer of the current question pointer value
     */
    public int questionPointer() {
        return questionPointer;
    }
}
