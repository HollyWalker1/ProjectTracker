package src;

import java.io.*;
import java.util.*;


public class User {

    private String username;
    private Map<String, Boolean> questionHistory = new HashMap<>();

    /*** User constructor : Allows User objects to be created and checks if the username is valid
     *
     * @param username - This a string of the user's inputted username
     */
    public User(String username){
        if (ifValidUsername(username)) {
            this.username = username;
        } else {
            throw new IllegalArgumentException("Invalid username");
        }
    }

    /*** getUsername : Getter for the username variable
     *
     * @return - Returns a string of the username
     */
    public String getUsername(){
        return username;
    }

    /*** setUsername : Setter for the username variable
     *
     * @param username - Sets the username variable to the string passed in
     */
    public void setUsername(String username){
        this.username = username;
    }

    /*** Static collections are used to store all users
     *
     */
    private static List<User> allUsers = new ArrayList<>();

    /*** addUser : Adds user to static list
     *
     * @param user - User object
     */
    public static void addUser(User user) {
        allUsers.add(user);
    }

    /*** userIfExtant : Check if the user exists
     *
     * @param username - String of the user's username
     * @return - Returns boolean, true if the user exists, false if it doesn't
     */
    public static boolean userIfExtant(String username){
        for(User user: allUsers){
            if (Objects.equals(user.getUsername(), username)){
                return true;
            }
        }
        return false;
    }
    // 新增：添加问题历史记录的方法

    /*** addQuestionHistory : adds QID and boolean isCorrect value into questionHistory map
     *
     * @param QID - String of the question id
     * @param isCorrect - boolean value of if the question was answered correctly
     */
    public void addQuestionHistory(String QID, boolean isCorrect) {
        questionHistory.put(QID, isCorrect);
    }
    // 新增：获取问题历史记录的方法

    /*** getQuestionHistory : Getter for the question history
     *
     * @return - Returns map of the question history
     */
    public Map<String, Boolean> getQuestionHistory() {
        if (this.questionHistory == null) {
            this.questionHistory = new HashMap<>();
        }
        return this.questionHistory;
    }

    //get all users from users.csv

    /*** getAllUsers : returns all users from a csv file
     *
     * @param filePath - a string of the csv file's filepath
     * @return - Returns the list of users
     * @throws IOException - Throws exception if there's a file error
     */
    public static List<User> getAllUsers(String filePath) throws IOException {
        List<User> users = new ArrayList<>();
        // Used to store existing usernames
        Set<String> existingUsernames = new HashSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length > 0) {
                String username = parts[0].trim();
                if (ifValidUsername(username) && !existingUsernames.contains(username)) {
                    users.add(new User(username));
                    // Adding a username to a collection of existing usernames
                    existingUsernames.add(username);
                }
            }
        }
        reader.close();
        return users;
    }


    /*
    Valid syntax for adding a username: length can only be 2-10 characters
    , if there are special symbols can only include _, can only be
    composed of letters or letters plus special symbols
    */

    /*** ifValidUsername : Checks if the username is valid
     *
     * @param username - String of the user's username
     * @return - Returns true if the username is valid
     */
    public static boolean ifValidUsername(String username){
        //Added error handling for null username
        if (username == null || username.isBlank()){
            throw new IllegalArgumentException("Invalid username");
        }

        if (username.length() < 2 || username.length() > 10){
            return false;
        }

        if (!Character.isUpperCase(username.charAt(0))){
            return false;
        }

        for (char c: username.toCharArray()){
            if (!Character.isLetterOrDigit(c) && c != '_'){
                return false;
            }
        }
        //If all authentication passes, the username is valid
        return true;
    }

    /*** saveAllUsers : saves the static list of users to the provided filepath
     *
     * @param users - This is the static list of users held in the class
     * @param filePath - This is a string of the destination file's filepath
     */
    public static void saveAllUsers(List<User> users, String filePath) {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(filePath, true));
            writer.newLine(); // Added a line break
            User lastUser = users.get(users.size() - 1); // get the last user
            writer.write(lastUser.getUsername() + ",null,null,null"); // just add the data of last user
        } catch (IOException e) {
            System.out.println("Error: Unable to save user data: " + e.getMessage());
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Error: Unable to close file writer: " + e.getMessage());
                }
            }
        }
    }

}