package src;

import src.User;

import java.util.*;
import java.io.IOException;

public class UserLog {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Load all users from the database/users.csv file
            List<User> existingUsers = User.getAllUsers("database/users.csv");

            // Preventing the display of duplicate user names
            Set<String> usernames = new HashSet<>();
            Iterator<User> iterator = existingUsers.iterator();
            while (iterator.hasNext()) {
                User user = iterator.next();
                if (!usernames.add(user.getUsername())) {
                    // Remove duplicate user
                    iterator.remove();
                }
            }
            System.out.println("1. Continue Existing user");
            System.out.println("2. Create new user");
            System.out.print("Please select operation：");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                // show all extant users
                System.out.println("Existing user records are as follows：");
                for (User user : existingUsers) {
                    System.out.println(user.getUsername());
                }

                // choose one user to continue quiz
                System.out.print("Please select an existing user for testing：");
                String username = scanner.nextLine();

                // check if user is exist
                boolean userExists = false;
                for (User user : existingUsers) {
                    if (user.getUsername().equals(username)) {
                        System.out.println("Existing user selected：" + username);
                        userExists = true;
                        break;
                    }
                }
                if (!userExists) {
                    System.out.println("Error: main.User does not exist！");
                    System.exit(1);
                }
            } else if (choice == 2) {
                System.out.print("Please enter a new user name：");
                String username = scanner.nextLine();

                // check if user is exist
                boolean userExists = false;
                for (User user : existingUsers) {
                    if (user.getUsername().equals(username)) {
                        System.out.println("Error: main.User already exists！");
                        userExists = true;
                        break;
                    }
                }
                if (!userExists) {
                    // create new user
                    User newUser = new User(username);
                    existingUsers.add(newUser);
                    System.out.println("New user created：" + username);

                    //save the new user data to users.csv
                    User.saveAllUsers(existingUsers, "database/users.csv");
                    System.out.println("User data saved successfully.");
                }
            } else {
                System.out.println("Error: Ineffective choices！");
                // exit program
                System.exit(1);
            }
        } catch (IOException e) {
            System.out.println("Error: Unable to load user data：" + e.getMessage());
            // exit program
            System.exit(1);
        }

        scanner.close();
    }
}
