// JUnit 5.8.1

package test;
import src.Questions;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

import java.util.Arrays;
import java.util.List;

/** Class TestQuestions : This class tests the methods inside the Questions class
 *
 */
public class TestQuestions extends Questions {
    @Test
    public void testEqualsTrue() throws IOException {
        // Tests questions are equal with themselves
        Questions questions1 = new Questions();
        questions1.loadDatabase("database/questions.csv");
        Assert.assertTrue(questions1.equals(questions1));
        // Tests questions are equal with separate but identical objects
        Questions questions2 = new Questions();
        questions2.loadDatabase("database/questions.csv");
        Assert.assertTrue(questions1.equals(questions2));
    }
    @Test
    public void testEqualsFalse() throws IOException {
        // Tests that when equals should return false, it returns false
        Questions questions1 = new Questions();
        questions1.loadDatabase("database/questions.csv");
        Assert.assertFalse(questions1.equals(null));
        Questions questions2 = new Questions();
        Assert.assertFalse(questions1.equals(questions2));
    }
    @Test
    public void testToStringTrue() {
        // Tests that toString returns the string representation of the object in the correct layout
        Questions questions1 = new Questions();
        Assert.assertEquals("Questions{questions=[], database='null'}", questions1.toString());
    }
    @Test
    public void testToStringFalse() {
        // Tests that toString doesn't return the same result for two objects holding different information
        Questions questions1 = new Questions();
        Questions questions2 = new Questions();
        questions2.addQuestion("What is 5 + 5?", "10", "single");
        Assert.assertNotEquals(questions2.toString(), questions1.toString());
    }
    @Test
    public void testHashCodeTrue() {
        // Tests that two objects holding identical information are equal after being hashed
        Questions questions1 = new Questions();
        Questions questions2 = new Questions();
        Assert.assertEquals(questions1.hashCode(), questions2.hashCode());
    }
    @Test
    public void testHashCodeFalse() {
        // Tests that two objects holding different information aren't equal after being hashed
        Questions questions1 = new Questions();
        Questions questions2 = new Questions();
        questions2.addQuestion("What is 5 + 5?", "10", "single");
        Assert.assertNotEquals(questions1.hashCode(), questions2.hashCode());
    }
    @Test
    public void testSaveLoadTrue() throws IOException {
        // Tests that information held in an object can successfully be saved to a csv file and then loaded
        Questions questions1 = new Questions();
        Questions questions2 = new Questions();
        questions2.addQuestion("What is 5 + 5?", "10", "single");
        questions2.saveDatabase("questions2.csv");
        questions1.loadDatabase("database/questions2.csv");
        // Checks that after being loaded they are both equal
        Assert.assertEquals(questions1.getFullQuestionDetails(), questions2.getFullQuestionDetails());
    }
    @Test
    public void testSaveLoadFalse() throws IOException {
        // Tests that, after being saved, if the contents of the object are changed, they no longer match the contents in the csv file
        Questions questions1 = new Questions();
        Questions questions2 = new Questions();
        questions2.addQuestion("What is 5 + 5?", "10", "single");
        questions2.saveDatabase("questions2.csv");
        questions2.addQuestion("What is 5 + 10?", "15", "single");
        questions1.loadDatabase("database/questions2.csv");
        Assert.assertNotEquals(questions1.getFullQuestionDetails(), questions2.getFullQuestionDetails());
    }
    @Test
    public void testGetQuestionsByTypeTrue() {
        Questions questions1 = new Questions();
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        // Tests that type "single" returns the correct list of questions
        List<String> expected1 = Arrays.asList("question 1","question 2");
        Assert.assertEquals(expected1,questions1.getQuestionsByType("single"));
        // Tests that type "multiple" returns the correct list of questions
        List<String> expected2 = List.of("question 3");
        Assert.assertEquals(expected2,questions1.getQuestionsByType("multiple"));
    }
    @Test
    public void testGetQuestionsByTypeFalse() {
        Questions questions1 = new Questions();
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        // Tests that getQuestionsByType of type "single" doesn't also return questions of type "multiple"
        List<String> expected = Arrays.asList("question 1","question 2","question 3");
        Assert.assertNotEquals(expected,questions1.getQuestionsByType("single"));
    }
    @Test
    public void testGetQIDsByTypeTrue() {
        Questions questions1 = new Questions();
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        // Tests that type "single" returns the correct list of question IDs
        List<String> expected1 = Arrays.asList("Q1","Q2");
        Assert.assertEquals(expected1,questions1.getQIDsByType("single"));
        // Tests that type "multiple" returns the correct list of question IDs
        List<String> expected2 = List.of("Q3");
        Assert.assertEquals(expected2,questions1.getQIDsByType("multiple"));
    }
    @Test
    public void testGetQIDsByTypeFalse() {
        Questions questions1 = new Questions();
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        // Tests that getQIDsByType of type "single" doesn't also return questions IDs of type "multiple"
        List<String> expected = Arrays.asList("Q1","Q2","Q3");
        Assert.assertNotEquals(expected,questions1.getQIDsByType("single"));
    }
    @Test
    public void testGetQIDTrue() {
        Questions questions1 = new Questions();
        // Tests that the correct question ID is returned for the question given
        questions1.addQuestion("question 1", "answer 1", "single");
        Assert.assertEquals( "Q1",questions1.getQID("question 1"));
        // Tests that as questions are added, it still returns the correct question ID
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3", "single");
        Assert.assertEquals( "Q3",questions1.getQID("question 3"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testGetQIDFalse() {
        Questions questions1 = new Questions();
        // Tests that entering a question ID that doesn't exist returns an illegal argument exception
        questions1.getQID("Q10000000");
    }
    @Test
    public void testGetAnswerTrue() throws Exception {
        Questions questions1 = new Questions();
        // Tests that getAnswer returns the correct answer for a question of type single
        questions1.addQuestion("question 1", "answer 1", "single");
        List<String> expected1 = List.of("answer 1");
        Assert.assertEquals(expected1, questions1.getAnswer("Q1"));
        // Tests that getAnswer returns the correct answer for a question of type multiple
        questions1.addQuestion("question 2", "answer 2/answer 3", "multiple");
        List<String> expected2 = Arrays.asList("answer 2", "answer 3");
        Assert.assertEquals(expected2, questions1.getAnswer("Q2"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testGetAnswerFalse() throws Exception {
        Questions questions1 = new Questions();
        // Tests that getAnswer returns an illegal argument exception when entering a question ID that doesn't exist
        questions1.getAnswer("Q10000000000000000");
    }
    @Test
    public void testGetQuestionIDsTrue() {
        Questions questions1 = new Questions();
        // Tests that getQuestionIDs returns all the question's question IDs stored in the class
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        List<String> expected = Arrays.asList("Q1","Q2","Q3");
        Assert.assertEquals(expected, questions1.getQuestionIDs());
    }
    @Test
    public void testGetQuestionIDsEmpty() {
        Questions questions1 = new Questions();
        // Tests that getQuestionIDs returns an empty list
        List<String> expected = List.of();
        Assert.assertEquals(expected, questions1.getQuestionIDs());
    }
    @Test
    public void testGetAllQuestionsTrue() {
        Questions questions1 = new Questions();
        // Tests that getAllQuestions returns all questions stored in the questions class
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 2", "answer 2", "single");
        questions1.addQuestion("question 3", "answer 3/answer 4", "multiple");
        List<String> expected = Arrays.asList("question 1","question 2","question 3");
        Assert.assertEquals(expected,questions1.getAllQuestions());
    }
    @Test
    public void testGetAllQuestionsEmpty() {
        Questions questions1 = new Questions();
        // Tests that getAllQuestions returns an empty list if no questions have been added yet
        List<String> expected = List.of();
        Assert.assertEquals(expected,questions1.getAllQuestions());
    }
    @Test
    public void testModifyQuestionTrue() {
        Questions questions1 = new Questions();
        // Tests that modify question changes the question stored in the questions class with that question ID
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyQuestion("Q1","test question");
        Assert.assertEquals("test question", questions1.getQuestion("Q1"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testModifyQuestionFalse() {
        Questions questions1 = new Questions();
        // Tests that modifying a question with an invalid question ID returns an illegal argument exception
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyQuestion("Q10000000000","test question");
    }
    @Test
    public void testModifyTypeTrue() throws Exception {
        Questions questions1 = new Questions();
        // Tests that modify type changes the type and answer stored in the questions class
        // for the question with the specified question ID when type is single -> multiple
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyType("Q1", "multiple", "new answer/new answer 2");
        Assert.assertEquals("multiple", questions1.getType("Q1"));
        List<String> expected1 = Arrays.asList("new answer","new answer 2");
        Assert.assertEquals(expected1, questions1.getAnswer("Q1"));
        // Tests that modify type changes the type and answer stored in the questions class
        // for the question with the specified question ID when type is multiple -> single
        questions1.addQuestion("question 2", "answer 1/answer 2", "multiple");
        questions1.modifyType("Q2", "single", "new answer");
        Assert.assertEquals("single", questions1.getType("Q2"));
        List<String> expected2 = List.of("new answer");
        Assert.assertEquals(expected2, questions1.getAnswer("Q2"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testModifyTypeFalse() throws Exception {
        Questions questions1 = new Questions();
        // Tests that modifying a type with an answer that doesn't match produces an illegal argument exception
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyType("Q1", "multiple", "answer 2");
    }
    @Test
    public void testModifyAnswerTrue() throws Exception {
        Questions questions1 = new Questions();
        // Tests that modify answer changed the answer correctly with type single
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyAnswer("Q1", "answer 2");
        List<String> expected = List.of("answer 2");
        Assert.assertEquals(expected, questions1.getAnswer("Q1"));
        // Tests that modify answer changed the answer correctly with type multiple
        questions1.addQuestion("question 2", "answer 1/answer 2", "multiple");
        questions1.modifyAnswer("Q2", "answer 3/answer 4");
        List<String> expected2 = List.of("answer 3", "answer 4");
        Assert.assertEquals(expected2, questions1.getAnswer("Q2"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testModifyAnswerFalseSingle() {
        Questions questions1 = new Questions();
        // Tests that modify answer throws illegal argument exception if answer is multiple
        // when the type of the question is single
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyAnswer("Q1", "answer 2/answer 3");
    }
    @Test(expected = IllegalArgumentException.class)
    public void testModifyAnswerFalseMultiple() {
        Questions questions1 = new Questions();
        // Tests that modify answer throws illegal argument exception if answer is multiple
        // when the type of the question is single
        questions1.addQuestion("question 1", "answer 1/ answer 2", "multiple");
        questions1.modifyAnswer("Q1", "answer 3");
    }
    @Test
    public void testRemoveQuestionTrue() {
        Questions questions1 = new Questions();
        // Tests that remove question removes only removes the question corresponding to the question ID provided
        questions1.addQuestion("question 1", "answer 1/ answer 2", "multiple"); // Q1
        questions1.addQuestion("question 2", "answer 3/ answer 4", "multiple"); // Q2
        questions1.removeQuestion("Q1");
        List<String> expected = List.of("question 2");
        Assert.assertEquals(expected, questions1.getAllQuestions());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testRemoveQuestionFalse() {
        Questions questions1 = new Questions();
        // Tests that remove question returns an illegal argument exception when trying to remove a question
        // that doesn't exist
        questions1.removeQuestion("Q1");
    }
    @Test
    public void testGetTypeTrue() {
        Questions questions1 = new Questions();
        // Tests that get type returns the type of the question correctly
        questions1.addQuestion("question 1", "answer 1", "single");
        Assert.assertEquals("single", questions1.getType("Q1"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testGetTypeFalse() {
        Questions questions1 = new Questions();
        // Tests that get type throws an illegal argument exception when the question ID
        // doesn't exist in the questions class
        questions1.getType("Q1");
    }

    @Test
    public void testGetQuestionTrue() {
        Questions questions1 = new Questions();
        // Tests that get question returns the question correctly
        questions1.addQuestion("question 1", "answer 1", "single");
        Assert.assertEquals("question 1", questions1.getQuestion("Q1"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testGetQuestionFalse() {
        Questions questions1 = new Questions();
        // Tests that get question throws an illegal argument exception when the question ID
        // doesn't exist in the questions class
        questions1.getType("Q1");
    }
    @Test
    public void testAddQuestionTrue() {
        Questions questions1 = new Questions();
        // Tests that questions of type single can be added successfully
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.modifyAnswer("Q1", "answer 2");
        Assert.assertEquals("question 1", questions1.getQuestion("Q1"));
        // Tests that questions of type multiple can be added successfully
        questions1.addQuestion("question 2", "answer 1/answer 2", "multiple");
        Assert.assertEquals("question 2", questions1.getQuestion("Q2"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddQuestionRepeatFalse() {
        Questions questions1 = new Questions();
        // Tests that if a repeat question is added an illegal argument exception is thrown
        questions1.addQuestion("question 1", "answer 1", "single");
        questions1.addQuestion("question 1", "answer 2", "single");
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddQuestionSingleFalse() {
        Questions questions1 = new Questions();
        // Tests that if a question of type single is added with two answers an illegal argument exception is thrown
        questions1.addQuestion("question 1", "answer 1/answer 2", "single");
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddQuestionMultipleFalse() {
        Questions questions1 = new Questions();
        // Tests that if a question of type multiple is added with 1 answer an illegal argument exception is thrown
        questions1.addQuestion("question 1", "answer 1", "multiple");
    }
}
