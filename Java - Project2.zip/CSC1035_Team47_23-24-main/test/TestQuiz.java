// JUnit 5.8.1

package test;
// Imports
import src.Quiz;
import src.Questions;
import src.User;
import org.junit.Assert;
import org.junit.Test;
import java.io.IOException;
import java.util.List;


public class TestQuiz {

    @Test
    public void testQuizFunctionality() throws IOException {
        // Create Questions and User object
        Questions questions = new Questions();
        User user = new User("Username");
        // Load questions
        questions.loadDatabase("database/questions.csv");
        // Create Quiz object
        Quiz quiz = new Quiz(questions, user);

        Assert.assertTrue(quiz.getCorrectlyAnsweredQuestionIDs().isEmpty());

    }
    // Test for if all answers are left empty
    @Test
    public void testAnswerQuestionsAllEmpty() throws Exception {
        Questions questions = new Questions();
        User user = new User("Username");
        questions.loadDatabase("database/questions.csv");
        Quiz quiz = new Quiz(questions, user);

        quiz.answerQuestion(String.valueOf(null));

        List<String> correctAnswers = quiz.getCorrectlyAnsweredQuestionIDs();
        List<String> incorrectAnswers = quiz.getIncorrectlyAnsweredQuestionIDs();

        Assert.assertTrue(correctAnswers.isEmpty());
        Assert.assertTrue(incorrectAnswers.isEmpty());
    }
    // Lists correctly answered questions
    @Test
    public void testCorrectAnswerQuestions() throws Exception {
        Questions questions = new Questions();
        User user = new User("Lisa");
        questions.loadDatabase("database/questions.csv");
        Quiz quiz = new Quiz(questions, user);

        quiz.answerQuestion("correct_answer");
        List<String> CorrectAnswers = quiz.getCorrectlyAnsweredQuestionIDs();
        Assert.assertTrue(CorrectAnswers.contains("QID"));
    }
    // Lists incorrectly answered questions
    @Test
    public void testIncorrectAnswerQuestions() throws Exception {
        Questions questions = new Questions();
        User user = new User("Mike");
        questions.loadDatabase("database/questions.csv");
        Quiz quiz = new Quiz(questions, user);

        quiz.answerQuestion("incorrect_answer");
        List<String> IncorrectAnswers = quiz.getIncorrectlyAnsweredQuestionIDs();
        Assert.assertTrue(IncorrectAnswers.contains("QID"));
    }
    // Test to check if the quiz can be cleared
    @Test
    public void testRetakeQuiz() throws Exception {
        Questions questions = new Questions();
        User user = new User("Username");
        questions.loadDatabase("database/questions.csv");
        Quiz quiz = new Quiz(questions, user);

        quiz.answerQuestion("correct_answer1");
        quiz.answerQuestion("incorrect_answer1");
        quiz.answerQuestion("correct_answer2");

        quiz.retakeQuiz();

        List<String> correctAnswers = quiz.getCorrectlyAnsweredQuestionIDs();
        List<String> incorrectAnswers = quiz.getIncorrectlyAnsweredQuestionIDs();
        List<String> givenAnswers = quiz.getGivenAnswers();
        int totalQuestionsAsked = quiz.totalQuestionsAsked();
        int questionPointer = quiz.questionPointer();

        Assert.assertTrue(correctAnswers.isEmpty());
        Assert.assertTrue(incorrectAnswers.isEmpty());
        Assert.assertTrue(givenAnswers.isEmpty());
        Assert.assertEquals(0, totalQuestionsAsked);
        Assert.assertEquals(0, questionPointer);
    }

}

