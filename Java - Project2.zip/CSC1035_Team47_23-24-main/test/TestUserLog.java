// JUnit 5.8.1

package test;

import src.User;
import src.UserLog;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.util.List;

public class TestUserLog {
    @Test
    public void testListAllUsers() {
        // Redirect System.out for testing
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Mock user input
        String simulatedUserInput = "1\nQi\n"; // Choose option 1 and provide an existing user "Qi"

        // Mock InputStream with simulatedUserInput
        InputStream simulatedInputStream = new ByteArrayInputStream(simulatedUserInput.getBytes());
        System.setIn(simulatedInputStream);

        UserLog.main(new String[]{});
        // Verify the output
        String expectedOutput = "Existing user selected：Qi";
        assertTrue(outputStream.toString().contains(expectedOutput));

        // Verify if all existing usernames are listed
        String[] expectedUsernames = {"Qi", "Mike", "Lisa"};
        for (String username : expectedUsernames) {
            assertTrue(outputStream.toString().contains(username));
        }
    }

    @Test
    public void testCreateNewUser() throws IOException {
        // Simulate user input for creating a new user
        // Choose option 2 and provide a new username "NewUser"
        String simulatedUserInput = "2\nNewUser\n";

        // Simulate input stream with simulatedUserInput
        ByteArrayInputStream inputStream = new ByteArrayInputStream(simulatedUserInput.getBytes());
        System.setIn(inputStream);

        UserLog.main(new String[]{});
        // Load users again to check if the new user was created
        List<User> users = User.getAllUsers("database/users.csv");
        boolean userExists = false;
        for (User user : users) {
            if (user.getUsername().equals("NewUser")) {
                userExists = true;
                break;
            }
        }
        // Verify that the new user was created
        assertTrue(userExists, "New user should have been created successfully");
    }

    /*
    Test whether an error is reported if the newly created
    user name after selecting option 2 is the same as the user
    name stored in the users.csv
    */
    @Test
    public void testSameUserError() {
        // Redirect System.out for testing
        InputStream originalInput = System.in;
        String simulatedUserInput = "2\nExistingUser\n";
        InputStream inputStream = new ByteArrayInputStream(simulatedUserInput.getBytes());
        System.setIn(inputStream);

        // Call the main method of UserLog with mock data and assert an exception is thrown
        assertThrows(IllegalArgumentException.class, () -> {
            UserLog.main(new String[]{});
        });

        // Restore System.in
        System.setIn(originalInput);
    }

}