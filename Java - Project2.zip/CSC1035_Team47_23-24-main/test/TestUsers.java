// JUnit 5.8.1

package test;
import org.junit.Test;
import static org.junit.Assert.*;
import src.User;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;


public class TestUsers {
    @Test
    public void testGetUsername() {
        User user = new User("TestUser");
        // Verify that the method that gets the username returns the correct username
        assertEquals("TestUser", user.getUsername());
    }
    @Test
    public void testAddUser() {
        User user1 = new User("User1");
        User user2 = new User("User2");
        User.addUser(user1);

        assertTrue(User.userIfExtant("User1"));
        assertFalse(User.userIfExtant("User2"));
    }
    @Test
    public void testUserIfExtant() {
        User user1 = new User("User1");
        User user2 = new User("User2");
        User.addUser(user1);

        assertTrue(User.userIfExtant("User1"));
        assertFalse(User.userIfExtant("User2"));
    }
    @Test
    public void testAddQuestionHistory() {
        User user = new User("TestUser");
        user.addQuestionHistory("Q1", true);
        user.addQuestionHistory("Q2", false);

        Map<String, Boolean> questionHistory = user.getQuestionHistory();

        // Verify that question Q1 exists in the history record
        assertTrue(questionHistory.containsKey("Q1"));
        // Verify that the answer to question Q1 is true
        assertTrue(questionHistory.get("Q1"));

        assertTrue(questionHistory.containsKey("Q2"));
        assertFalse(questionHistory.get("Q2"));
    }

    @Test
    public void testGetQuestionHistory() {
        User user = new User("TestUser");
        user.addQuestionHistory("Q1", true);
        user.addQuestionHistory("Q2", false);
        Map<String, Boolean> questionHistory = user.getQuestionHistory();

        assertNotNull(questionHistory);
        assertEquals(2, questionHistory.size());
    }

    @Test
    public void testGetAllUsers() throws IOException {
        // create mock users data
        String filePath = "database/users_unique.csv";
        String testData = "Qi,What is 5 + 2?,true,single\n" +
                "Mike,What is 5 + 30?,false,single\n" +
                "Lisa,What is 9 x 10?,true,single\n";

        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        writer.write(testData);
        writer.close();

        // get all users
        List<User> users = User.getAllUsers(filePath);

        // Verify that the list of retrieved users is not empty
        assertNotNull(users);

        assertEquals(3, users.size());

        // Verify that the user's username is obtained
        assertEquals("Qi", users.get(0).getUsername());
        assertEquals("Mike", users.get(1).getUsername());
        assertEquals("Lisa", users.get(2).getUsername());
    }

    @Test
    public void testIfValidUsername() {
        // verify valid
        assertTrue(User.ifValidUsername("ValidUser"));

        // verify the username is too short
        assertFalse(User.ifValidUsername("U"));

        // verify the username is too long
        assertFalse(User.ifValidUsername("Username123456"));

        // Verify that the username starts with a lowercase letter
        assertFalse(User.ifValidUsername("invalidStart"));

        // Verify that the username contains special characters
        assertFalse(User.ifValidUsername("Special@User"));

        // Verify empty username
        assertThrows(IllegalArgumentException.class, () -> User.ifValidUsername(null));

        // Verify a blank username
        assertThrows(IllegalArgumentException.class, () -> User.ifValidUsername(""));
    }

    @Test
    public void testSaveAllUsers() throws IOException {
        // Create simulated user data
        List<User> users = List.of(
                new User("User1")
        );

        // Specify the test file path
        String filePath = "database/users.csv";

        User.saveAllUsers(users, filePath);
        List<User> savedUsers = User.getAllUsers(filePath);

        // Verify that the saved user data is correct
        assertNotNull(savedUsers);
        assertEquals(4, savedUsers.size());

        boolean newUserFound = false;
        for (User user : savedUsers) {
            if (user.getUsername().equals("User1")) {
                newUserFound = true;
                break;
            }
        }
        // Ensure that new users are saved to the file correctly
        assertTrue(newUserFound);
    }


}
