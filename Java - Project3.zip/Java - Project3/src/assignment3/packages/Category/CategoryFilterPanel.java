package assignment3.packages.Category;

import assignment3.packages.NewExpenses.Expense;
import assignment3.packages.NewExpenses.ExpensesManager;
import assignment3.packages.SavedExpenses.SavedExpensesPanel;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CategoryFilterPanel extends JPanel {
    private JButton sumButton;
    static JLabel sumLabel = new JLabel("Total : 0.00");
    private JComboBox<Category> filterComboBox;
    private JButton filterButton;
    private ExpensesManager expensesManager;
    private SavedExpensesPanel savedExpensesPanel;
    private JButton restoreButton;

    public CategoryFilterPanel(ExpensesManager expensesManager, SavedExpensesPanel savedExpensesPanel) {
        this.expensesManager = expensesManager;
        this.savedExpensesPanel = savedExpensesPanel;

        setLayout(new FlowLayout(FlowLayout.LEFT));

        filterComboBox = new JComboBox<>(Category.values());
        add(filterComboBox);

        filterButton = new JButton("Filter");
        add(filterButton);

        restoreButton = new JButton("Restore");
        add(restoreButton);

        sumButton = new JButton("Sum");
        add(sumButton);
        add(sumLabel);
    }

    // Methods to get the selected category

    public JButton getFilterButton() {
        return filterButton;
    }

    public JButton getRestoreButton() {
        return restoreButton;
    }

    public JButton getSumButton() {
        return sumButton;
    }

    public void clickSum(double total) {
        sumLabel.setText("Total : " + total);
    }

    public void applyFilter() {
        Category selectedCategory = (Category) filterComboBox.getSelectedItem();
        // Retrieve filtered expenses and update the table
        savedExpensesPanel.updateTable(expensesManager.getExpensesByCategory(selectedCategory));
    }

    public void restoreFilter(){

        List<Expense> previouslySavedExpenses = savedExpensesPanel.getpreviouslySavedExpenses();
        if (previouslySavedExpenses != null) {
            savedExpensesPanel.updateTable(previouslySavedExpenses);
        }
    }



}
