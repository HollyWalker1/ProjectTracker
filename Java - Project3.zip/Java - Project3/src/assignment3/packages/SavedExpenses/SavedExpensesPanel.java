package assignment3.packages.SavedExpenses;

import assignment3.packages.NewExpenses.Expense;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SavedExpensesPanel extends JPanel {
    private SavedExpenses savedExpenses;
    private JTable jsavedExpenseTable;

    private List<Expense> previouslySavedExpenses;


    public SavedExpensesPanel() {
        setLayout(new BorderLayout());

        // Initially empty and ready to be added or exported
        savedExpenses = new SavedExpenses(new ArrayList<>());
        jsavedExpenseTable = new JTable(savedExpenses);

        JScrollPane scrollPane = new JScrollPane(jsavedExpenseTable);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void updateTable(List<Expense> expenses) {
        previouslySavedExpenses = savedExpenses.getExpenses();

        savedExpenses.setExpenses(expenses);
    }


    public List<Expense> getpreviouslySavedExpenses() {
        return previouslySavedExpenses;
    }


    // method to select the saved expense for further manipulation
    public int getSavedSelectedExpenseIndex() {
        return jsavedExpenseTable.getSelectedRow(); // Returns -1 if no row is selected
    }

    public double getTotal(JFrame frame) {
        double total = 0;
        String temp;
        for (int i = 0; i < savedExpenses.getExpenses().size(); i++) {
            temp = savedExpenses.getExpenses().get(i + 1).currency();
            if (temp != savedExpenses.getExpenses().get(i).currency()) {
                JOptionPane.showMessageDialog(frame, "Currency must be of the same type","Invalid Currency Types", JOptionPane.ERROR_MESSAGE);
                return 0.0;
            }
            total = total + savedExpenses.getExpenses().get(i).amount();
        }
        return total;
    }

}
