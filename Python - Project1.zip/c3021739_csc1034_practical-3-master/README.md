Practical 3
===========

This package is build as a part of CSC1034 Project 3. The optimisation testing report is in REPORT.md. 

To run page_rank.py use the following commands:

Stochastic : python page_rank.py "file.txt".

Distribution : python page_rank.py "file.txt" -m distribution.

Change number of repetitions in the stochastic algorithm (default is 1000000)  : python page_rank.py "file.txt" -r (number).

Change number of steps in the distribution algorithm (default is 100)  : python page_rank.py "file.txt" -s (number).

Change number of results shown (default is 20)  : python page_rank.py "file.txt" -n (number).