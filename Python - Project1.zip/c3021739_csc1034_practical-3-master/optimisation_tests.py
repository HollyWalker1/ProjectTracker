import time
import networkx as nx
import random


"""Dictionary graph time testing"""


def load_test_1(file):
    start = time.time()
    graph = {}
    for line in file:
        node, target = line.split()
        if node not in graph:
            graph[node] = [target]
        else:
            graph[node].append(target)
    stop = time.time()
    return (stop - start), graph


test_time, graph_test_1 = load_test_1(open('school_web.txt'))


def stats_test_1(graph):
    start = time.time()
    print("Number of nodes: ", len(graph.keys()))
    count = 0
    for node in graph:
        count = len(graph[node]) + count
    print("Number of edges: ", count)
    stop = time.time()
    return stop - start


test_time = stats_test_1(graph_test_1) + test_time


def stochastic_test_1(graph):
    start = time.time()
    hit_count = {}
    nodes = list(graph)
    for node in graph:
        hit_count[node] = 0
    current_node = random.choice(nodes)
    hit_count[current_node] += 1
    for i in range(0, 1000000):
        out_edges = graph[current_node]
        if len(out_edges) == 0:
            current_node = random.choice(nodes)
        else:
            current_node = random.choice(out_edges)
        hit_count[current_node] += 1
    stop = time.time()
    return stop - start


test_time_stochastic = stochastic_test_1(graph_test_1) + test_time
print(f"Dictionary method (stochastic) took {test_time_stochastic:.4f} seconds.\n")


def distribution_test_1(graph):
    start = time.time()
    node_prob = {}
    next_prob = {}

    for node in graph:
        node_prob[node] = 1 / len(graph.keys())
        next_prob[node] = 0

    for i in range(0, 100):
        for node in graph:
            out_edges = graph[node]
            p = node_prob[node] / len(out_edges)
            for target in out_edges:
                next_prob[target] += p
        node_prob = next_prob
    stop = time.time()
    return stop - start


test_time_distribution = distribution_test_1(graph_test_1) + test_time
print(f"Dictionary method (distribution) took {test_time_distribution:.4f} seconds.\n")


"""Networkx graph time testing"""


def load_test_2(file):
    start = time.time()
    graph = nx.DiGraph()
    for line in file:
        node, target = line.split()
        if node not in graph.nodes():
            graph.add_node(node)
            graph.add_edge(node, target)
        else:
            graph.add_edge(node, target)
    stop = time.time()
    return (stop - start), graph


test_time, graph_test_2 = load_test_2(open('school_web.txt'))


def stats_test_2(graph):
    start = time.time()
    print("Number of nodes: ", graph.number_of_nodes())
    print("Number of edges: ", graph.number_of_edges())
    stop = time.time()
    return stop - start


test_time = stats_test_2(graph_test_2) + test_time


def stochastic_test_2(graph):
    start = time.time()

    hit_count = {}

    current_node = random.choice(list(graph.nodes()))
    hit_count[current_node] = 1

    for i in range(0, 1000000):
        if graph.degree(current_node) == 0:
            current_node = random.choice(list(graph.nodes()))
        else:
            current_node = random.choice(list(graph.neighbors(current_node)))
        if current_node not in hit_count:
            hit_count[current_node] = 1
        else:
            hit_count[current_node] += 1
    stop = time.time()
    return stop - start


test_time_stochastic = stochastic_test_2(graph_test_2) + test_time
print(f"Networkx method (stochastic) took {test_time_stochastic:.4f} seconds.\n")


def distribution_test_2(graph):
    start = time.time()
    node_prob = {}
    next_prob = {}
    for node in graph:
        node_prob[node] = 1 / len(graph.nodes())
        next_prob[node] = 0
    for i in range(0, 100):
        for node in graph:
            out_edges = list(graph.neighbors(node))
            p = node_prob[node] / len(out_edges)
            for target in out_edges:
                next_prob[target] += p
        node_prob = next_prob
    stop = time.time()
    return stop - start


test_time_distribution = distribution_test_2(graph_test_2) + test_time
print(f"NetworkX method (distribution) took {test_time_distribution:.4f} seconds.\n")


"""Class graph time testing"""


class Graph:
    def __init__(self):
        self.nodes = {}
        self.edge_count = 0

    def get_nodes(self):
        return self.nodes.keys()

    def get_node_edges(self,node):
        return self.nodes[node]

    def get_edge_count(self):
        return self.edge_count

    def add_node(self, node, target):
        self.nodes[node] = [target]
        self.edge_count += 1

    def add_edge(self, node, target):
        self.nodes[node].append(target)
        self.edge_count += 1


def load_test_3(file):
    start = time.time()
    graph = Graph()
    for line in file:
        node, target = line.split()
        if node not in graph.get_nodes():
            graph.add_node(node, target)
        else:
            graph.add_edge(node, target)
    stop = time.time()
    return (stop - start), graph


test_time, graph_test_3 = load_test_3(open('school_web.txt'))


def stats_test_3(graph):
    start = time.time()
    print("Number of nodes: ", len(graph.get_nodes()))
    print("Number of edges: ", graph.get_edge_count())
    stop = time.time()
    return stop - start


test_time = stats_test_3(graph_test_3) + test_time


def stochastic_test_3(graph):
    start = time.time()
    hit_count = {}
    for node in graph.get_nodes():
        hit_count[node] = 0
    current_node = random.choice(list(graph.get_nodes()))
    hit_count[current_node] += 1
    for i in range(0, 1000000):
        if len(graph.get_node_edges(current_node)) == 0:
            current_node = random.choice(graph.get_nodes())
        else:
            current_node = random.choice(graph.get_node_edges(current_node))
        hit_count[current_node] += 1
    stop = time.time()
    return stop - start


test_time_stochastic = stochastic_test_3(graph_test_3) + test_time
print(f"Class method (stochastic) took {test_time_stochastic:.4f} seconds.\n")


def distribution_test_3(graph):
    start = time.time()
    node_prob = {}
    next_prob = {}
    for node in graph.get_nodes():
        node_prob[node] = 1 / len(graph.get_nodes())
        next_prob[node] = 0
    for i in range(0, 100):
        for node in graph.get_nodes():
            out_edges = graph.get_node_edges(node)
            p = node_prob[node] / len(out_edges)
            for target in out_edges:
                next_prob[target] += p
        node_prob = next_prob
    stop = time.time()
    return stop - start


test_time_distribution = distribution_test_3(graph_test_3) + test_time
print(f"Class method (distribution) took {test_time_distribution:.4f} seconds.\n")
