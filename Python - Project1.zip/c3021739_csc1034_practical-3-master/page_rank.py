import sys
import time
import argparse
import random

def load_graph(args):
    """Load graph from text file

    Parameters:
    args -- arguments named tuple

    Returns:
    A dict mapling a URL (str) to a list of target URLs (str).
    """
    graph = {}
    # Iterate through the file line by line
    for line in args.datafile:
        # And split each line into two URLs
        node, target = line.split()
        # Adds node to graph dictionary if it doesn't already exist
        # with the target node as the key's value (as a list)
        if node not in graph:
            graph[node] = [target]
        # If the node is already in the graph, the target is added
        # to the list of values
        else:
            graph[node].append(target)
    return graph

def print_stats(graph):
        """Print number of nodes and edges in the given graph"""
        print("Number of nodes: ", len(graph.keys()))
        count = 0
        # The value stored in each key value pair is a list so the amount
        # of edges needs to be individually calculated for each node
        for node in graph:
            count = len(graph[node]) + count
        print("Number of edges: ", count)

def stochastic_page_rank(graph, args):
    """Stochastic PageRank estimation

    Parameters:
    graph -- a graph object as returned by load_graph()
    args -- arguments named tuple

    Returns:
    A dict that assigns each page its hit frequency

    This function estimates the Page Rank by counting how frequently
    a random walk that starts on a random node will after n_steps end
    on each node of the given graph.
    """

    hit_count = {}
    nodes = list(graph)

    # Gives each node a hit count of 0 initially
    for node in graph:
        hit_count[node] = 0

    # First node is randomly chosen
    current_node = random.choice(nodes)
    # Gives the first node a value of 1
    hit_count[current_node] += 1

    # Repeatedly starts a walk from the current node
    for i in range(0, args.repeats):
        # out_edges contains all target nodes for the current node
        out_edges = graph[current_node]
        # If there are no target nodes, a new node is randomly selected
        if len(out_edges) == 0:
            current_node = random.choice(nodes)
        # If there are target nodes, one of them is randomly chosen as
        # the new current node
        else:
            current_node = random.choice(out_edges)
        # Hit count for the current node is incremented
        hit_count[current_node] += 1

    return hit_count

def distribution_page_rank(graph, args):
    """Probabilistic PageRank estimation

    Parameters:
    graph -- a graph object as returned by load_graph()
    args -- arguments named tuple

    Returns:
    A dict that assigns each page its probability to be reached

    This function estimates the Page Rank by iteratively calculating
    the probability that a random walker is currently on any node.
    """

    node_prob = {}
    next_prob = {}

    # Initial node probability/next probability is set
    for node in graph:
        node_prob[node] = 1/len(graph.keys())
        next_prob[node] = 0

    # Repeatedly calculates probability
    for i in range(0, args.steps):
        # For each node, the node probability is recalculated
        # based on the amount of target nodes it has
        for node in graph:
            out_edges = graph[node]
            # P stores the result of the node probability divided
            # by the node's out degree
            p = node_prob[node] / len(out_edges)
            # Each target node's probability is increased by the
            # value of p
            for target in out_edges:
                next_prob[target] += p
        node_prob = next_prob

    return node_prob

# Command line arguments
parser = argparse.ArgumentParser(description="Estimates page ranks from link information")
parser.add_argument('datafile', nargs='?', type=argparse.FileType('r'), default=sys.stdin,
                    help="Textfile of links among web pages as URL tuples")
parser.add_argument('-m', '--method', choices=('stochastic', 'distribution'), default='stochastic',
                    help="selected page rank algorithm")
parser.add_argument('-r', '--repeats', type=int, default=1_000_000, help="number of repetitions")
parser.add_argument('-s', '--steps', type=int, default=100, help="number of steps a walker takes")
parser.add_argument('-n', '--number', type=int, default=20, help="number of results shown")

# Main program
if __name__ == '__main__':
    args = parser.parse_args()
    algorithm = distribution_page_rank if args.method == 'distribution' else stochastic_page_rank

    graph = load_graph(args)

    print_stats(graph)

    start = time.time()
    ranking = algorithm(graph, args)
    stop = time.time()
    time = stop - start

    top = sorted(ranking.items(), key=lambda item: item[1], reverse=True)
    sys.stderr.write(f"Top {args.number} pages:\n")
    print('\n'.join(f'{100*v:.2f}\t{k}' for k,v in top[:args.number]))
    sys.stderr.write(f"Calculation took {time:.2f} seconds.\n")
