Project 2

===========

This package is build as a part of the CSC1034: Project 2.

The item file contains the function Item, the item_manager file contains the ItemManager function. The test files are located in the tests directory, test_item tests the methods of Item, test_item_manager tests the methods of ItemManager.

The purpose of all methods, classes and testing functions are explained through docstrings and comments in their respective files.