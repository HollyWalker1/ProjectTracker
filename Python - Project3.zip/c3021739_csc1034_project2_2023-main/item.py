# The item class allows for the creation of and maintenance of items
class Item:
    # The constructor allows for items to be created so long as they are
    # of the correct type and meet the specified constraints
    def __init__(self, name, category, perishable, stock, sell_price):
        if not isinstance(name, str):
            raise TypeError("Name should be a string")
        if not isinstance(category, str):
            raise TypeError("Category should be a string")
        if not isinstance(perishable, bool):
            raise TypeError("Perishable should be boolean")
        if not isinstance(stock, int):
            raise TypeError("Stock should be an integer")
        if not isinstance(sell_price, float):
            raise TypeError("Sell price should be a float")
        # stock and sell_price cannot be negative and therefore return
        # an IOError
        if stock < 0:
            raise IOError("Stock cannot be less than 0")
        if sell_price < 0.00:
            raise IOError("Sell price cannot be less than 0")
        self.name = name
        self.category = category
        self.perishable = perishable
        self.stock = stock
        self.sell_price = sell_price

    # This returns the value stored in self.name
    def get_name(self):
        return self.name

    # This returns the value stored in self.category
    def get_category(self):
        return self.category

    # This returns the value stored in self.perishable
    def get_perishable(self):
        return self.perishable

    # This returns the value stored in self.stock
    def get_stock(self):
        return self.stock

    # This returns the value stored in self.sell_price
    def get_sell_price(self):
        return self.sell_price

    # This is called by ItemManager to apply a discount within the
    # item, updating self.sell_price to the new value
    def set_discount(self, discount):
        self.sell_price = self.sell_price * (1 -(discount/100))

    # This decreases stock by one when an item is purchased using the
    # purchase_available_items method in ItemManager
    def decrement_stock(self):
        self.stock = self.stock - 1

    # This returns the string representation of the item in an
    # easy-to-read format
    def __str__(self):
        return f"Item name is {self.name}, category is {self.category}, perishable status is {self.perishable}, stock is {self.stock} and sell price is {self.sell_price}"

    # This returns a string representation of the item in a format
    # that allows for the item to be recreated
    def __repr__(self):
        return f"Item(\"{self.name}\", \"{self.category}\", {self.perishable}, {self.stock}, {self.sell_price})"

    # This checks if one Item object is the same as another
    # Item object and returns True or False
    def __eq__(self, other):
        if not isinstance(other, Item):
            return False
        return self.name == other.name

    # This creates a hash based on all the values stored in an item
    def __hash__(self):
        return hash((self.name, self.category, self.perishable, self.stock, self.sell_price))
