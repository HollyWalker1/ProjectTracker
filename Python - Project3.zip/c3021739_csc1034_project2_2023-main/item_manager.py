import csv
from item import Item


# Class ItemManager will allow for creation and maintenance a list of items (of type Item)
class ItemManager:
    # Constructor for the class, accepts optional parameter
    def __init__(self, items=None):
        # If items isn't passed in, the constructor will create an empty list of items
        if items is None:
            self.items = []
        else:
            if not isinstance(items, list):
                raise TypeError("items should be a list")
            self.items = items

    # get_item returns a list containing all the items in self.items
    def get_items(self):
        return self.items

    # __str__ returns a string containing all the items in self.items
    def __str__(self):
        return f"Items include: {self.items}"

    # __repr__ returns a string containing all the items in self.items in the format
    # that could be used to create another object of the class
    def __repr__(self):
        return f"ItemManager{self.items}"

    # add_item adds an item to the self.items list if it isn't already in the list
    def add_item(self, item):
        if not isinstance(item, Item):
            raise TypeError("item should be of type Item")
        if item not in self.items:
            self.items.append(item)

    # removes_item removes a specified item (of type Item) from self.items
    def remove_item(self, item):
        if not isinstance(item, Item):
            raise TypeError("item should be of type Item")
        self.items.remove(item)

    # edit_item changes the old_item into the new_item by removing the old
    # item and adding the new item
    def edit_item(self, old_item, new_item):
        if not isinstance(old_item, Item) or not isinstance(new_item, Item):
            raise TypeError("Old and new item should be of type Item")
        self.items.remove(old_item)
        self.items.append(new_item)

    # search_by_category searches through all items in self.items and returns
    # only the items with the matching category
    def search_by_category(self, category):
        if not isinstance(category, str):
            raise TypeError("Category should be of type string")
        items_result = []
        for i in range(0,len(self.items)):
            if self.items[i].get_category() == category:
                items_result.append(self.items[i])
        return items_result

    # search_by_perishable searches through all items in self.items and returns
    # only the items with the matching perishable status
    def search_by_perishable(self, perishable):
        if not isinstance(perishable, bool):
            raise TypeError("Perishable should be of type boolean")
        items_result = []
        for i in range(0, len(self.items)):
            if self.items[i].get_perishable() == perishable:
                items_result.append(self.items[i])
        return items_result

    # search_by_sell_price searches through all items in self.items and returns
    # only the items with the matching sell price
    def search_by_sell_price(self, sell_price):
        if not isinstance(sell_price, float):
            raise TypeError("Sell price should be of type float")
        items_result = []
        for i in range(0, len(self.items)):
            if self.items[i].get_sell_price() == sell_price:
                items_result.append(self.items[i])
        return items_result

    # apply_discount_to_items applies discounts only if the discount
    # is between 0 and 50 and of type int
    def apply_discount_to_items(self, names, discount):
        if not isinstance(names, list) or not isinstance(discount, int):
            raise TypeError("Names should be of type list and discount should be of type integer")
        if discount < 50 and discount > 0:
            for i in range(0, len(self.items)):
                if self.items[i].get_name() in names:
                    self.items[i].set_discount(discount)
        else:
            raise IOError("Discount must be between 0 and 50")

    # purchase_available_items allows items to be purchased
    def purchase_available_items(self, names, is_member):
        if not isinstance(names, list):
            raise TypeError("Names should be of type list")
        if not isinstance(is_member, bool):
            raise TypeError("is_member should be of type boolean")
        purchase_total = 0.00
        for i in range(0, len(names)):
            for j in range(0, len(self.items)):
                # if the purchased item exists in self.items this runs
                if names[i] == self.items[j].get_name():
                    # if the stock isn't 0, the stock decrements by 1
                    # and the sell price is added to purchase_total
                    if self.items[j].get_stock() > 0:
                        self.items[j].decrement_stock()
                        purchase_total = purchase_total + self.items[j].get_sell_price()
                    else:
                        raise ValueError("Item chosen is out of stock")
        # if purchase_total is greater than or equal to 50.00, a discount
        # of 10% is applied so long as is_member is true
        if purchase_total >= 50.00 and is_member:
            purchase_total = purchase_total * 0.9
        # if purchase_total is less than 50.00, a discount 5% is applied
        # so long as is_member is true
        elif is_member:
            purchase_total = purchase_total * 0.95
        return purchase_total

    # load_from_file loads the items contained in a file and stores them
    # as a set of items
    def load_from_file(self, file_name):
        if not isinstance(file_name, str):
            raise TypeError("file_name should be of type string")
        # Adapted from
        # https://www.analyticsvidhya.com/blog/2021/08/python-tutorial-working-with-csv-file-for-data-science/
        instances_list = []
        with open(file_name, 'r') as file:
            csv_reader = csv.reader(file)
            # skips over the first line which contains the parameter names
            file.readline()
            # Makes sure that boolean values are correctly handled
            for row in csv_reader:
                if row[2] == "True":
                    row[2] = True
                else:
                    row[2] = False
                instances_list.append(Item(str(row[0]), str(row[1]), row[2], int(row[3]), float(row[4])))
        self.items = instances_list

    #save_to_file saves all the items stored in self.items into a file
    def save_to_file(self, file_name):
        if not isinstance(file_name, str):
            raise TypeError("file_name should be of type string")
        # Adapted from
        # https://www.programiz.com/python-programming/writing-csv-files
        with open(file_name, "w", newline="") as file:
            csv_writer = csv.writer(file)
            # writes out the categories first
            csv_writer.writerow(["name", "category", "perishable", "stock", "sell_price"])
            for i in range(0,len(self.items)):
                current_item = self.items[i]
                csv_writer.writerow([current_item.get_name(), current_item.get_category(), current_item.get_perishable(), current_item.get_stock(), current_item.get_sell_price()])