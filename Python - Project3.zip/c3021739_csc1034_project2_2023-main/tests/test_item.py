from item import Item
"""Test : Item parameters type constraints (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_item_type_normal():
    item = Item("Apple", "Grocery", True, 2, 0.69)
    assert type(item.get_name()) is str
    assert type(item.get_category()) is str
    assert type(item.get_perishable()) is bool
    assert type(item.get_stock()) is int
    assert type(item.get_sell_price()) is float


# Checks that incorrect input type returns type errors
def test_item_type_error():
    print("")
    try:
        item = Item("Apple", "Grocery", True, "2", 0.69)
    except TypeError:
        print("""              Invalid stock type (str) produces TypeError""")

    try:
        item = Item("Apple", "Grocery", "True", 2, 0.69)
    except TypeError:
        print("              Invalid perishable type (str) produces TypeError")

    try:
        item = Item("Apple", "Grocery", True, 2, 1)
    except TypeError:
        print("              Invalid sell_price type (int) produces TypeError")


"""Test : Item stock/sell price constraints (Boundary and Error Cases)"""


# Checks that the stock boundary case (where value is 0) is
# still processed and no errors are raised
def test_item_stock_boundary():
    item = Item("Apple", "Grocery", True, 0, 0.69)


# Checks that the incorrect input amount (negative) returns
# an IOError
def test_item_stock_error():
    print("")
    try:
        item = Item("Apple", "Grocery", True, -2, 0.69)
    except IOError:
        print("              Invalid stock (negative) produces IOError")


# Checks that the sell_price boundary case (0.00) is
# still processed without any errors raised
def test_item_sell_price_boundary():
    item = Item("Apple", "Grocery", True, 1, 0.00)


# Checks that the incorrect input (negative) returns an
# IOError
def test_item_sell_price_error():
    print("")
    try:
        item = Item("Apple", "Grocery", True, 1, -1.50)
    except IOError:
        print("              Invalid sell price (negative) produces IOError")


"""Test : Item __eq__ constraints (Normal and Error Cases)"""


# Checks that when __eq__ has the correct inputs it returns True/False when it should
def test_item_eq_normal():
    item_1 = Item("Apple", "Grocery", True, 2, 0.69)
    item_2 = Item("Apple", "Grocery", True, 2, 0.69)
    assert item_1.__eq__(item_2)
    item_1 = Item("Apple", "Grocery", True, 2, 0.69)
    item_2 = Item("Mango", "Grocery", True, 2, 0.69)
    assert (item_1.__eq__(item_2)) == False


# Checks that when a non-item is passed into __eq__ as other, False is returned
def test_item_eq_error():
    item_1 = Item("Apple", "Grocery", True, 2, 0.69)
    item_2 = "Mango"
    assert item_1.__eq__(item_2) == False