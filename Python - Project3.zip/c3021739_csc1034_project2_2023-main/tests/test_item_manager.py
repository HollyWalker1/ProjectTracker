from item_manager import ItemManager
from item import Item


"""Test : ItemManager parameters type constraints (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_type_normal():
    list_1 = ItemManager()
    assert list_1.get_items() == []
    list_1.load_from_file("sample_data_2.csv")
    assert list_1.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Mango", "Food", True, 1, 1.0)]


# Checks that incorrect input type produces error
def test_manager_type_error():
    print("")
    try:
        list_1 = ItemManager("Apple")
    except TypeError:
        print("              Invalid items type (str) produces TypeError")


"""Test : ItemManager add_item constraints test (Normal and Error Cases)"""


# Checks that correct input is processed correctly
def test_manager_add_normal():
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    list_1.add_item(Item("Peach", "Food", True, 5, 1.10))
    assert list_1.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Mango", "Food", True, 1, 1.0), Item("Peach", "Food", True, 5, 1.10)]


# Checks that incorrect input (duplicate items) produces error
def test_manager_add_error():
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    list_1.add_item(Item("Peach", "Food", True, 5, 1.10))
    list_1.add_item(Item("Peach", "Food", True, 2, 1.60))
    # Checks that there is no duplicates
    assert list_1.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Mango", "Food", True, 1, 1.0), Item("Peach", "Food", True, 5, 1.10)]


"""Test : ItemManager remove_item type constraints test (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_remove_normal():
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    list_1.remove_item(Item("Apple", "Food", True, 2, 1.5))
    assert list_1.get_items() == [Item("Mango", "Food", True, 1, 1.0)]


# Checks that incorrect input type produces error
def test_manager_remove_error():
    print("")
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    try:
        list_1.remove_item(Item("Apple"))
    except TypeError:
        print("              Invalid item type (str) produces TypeError")


"""Test : ItemManager edit_item type constraints test (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_edit_normal():
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    new_item = Item("Grapes", "Food", True, 5, 2.0)
    list_1.edit_item(Item("Mango", "Food", True, 1, 1.0), new_item)
    assert list_1.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Grapes", "Food", True, 5, 2.0)]


# Checks that incorrect input type produces error
def test_manager_edit_error():
    print("")
    list_1 = ItemManager()
    # Contains two items (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    try:
        list_1.edit_item(Item("Mango", "Food", True, 1, 1.0), "Grapes")
    except TypeError:
        print("              Invalid item type (str) produces TypeError")


"""Test : ItemManager search_by_category type test (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_category_search_normal():
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    assert list_1.search_by_category("Grocery - Chilled") == [Item("Vegan Creamy Garlic Mushroom Slice", "Grocery - Chilled", True, 93, 0.4), Item("Fat Free Banana and Custard Yogurt", "Grocery - Chilled", True, 13, 5.19)]


# Checks that incorrect input type produces error
def test_manager_category_search_error():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    try:
        list_1.search_by_category(True)
    except TypeError:
        print("              Invalid category type (boolean) produces TypeError")


"""Test : ItemManager search_by_perishable type test (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_perishable_search_normal():
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    # Contains all items in sample_data.csv which are perishable
    perishable_items = [Item("Vegan Creamy Garlic Mushroom Slice", "Grocery - Chilled", True, 93, 0.4), Item("Fat Free Banana and Custard Yogurt", "Grocery - Chilled", True, 13, 5.19), Item("Chicago Town BBQ Crust Deep Dish Memphis Style BBQ Pork", "Grocery - Frozen", True, 24, 3.14), Item("4 Frozen Baked Jacket Potatoes", "Grocery - Frozen", True, 47, 7.36), Item("Crispy Sweet Potato Fries", "Grocery - Frozen", True, 98, 2.99)]
    assert list_1.search_by_perishable(True) == perishable_items


# Checks that incorrect input type produces error
def test_manager_perishable_search_error():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    try:
        list_1.search_by_perishable("True")
    except TypeError:
        print("              Invalid perishable type (string) produces TypeError")


"""Test : ItemManager search_by_sell_price type test (Normal and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_sell_price_search_normal():
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    assert list_1.search_by_sell_price(9.32) == [Item("Zog by Julia Donaldson", "Books - Paperback", False, 19, 9.32)]


# Checks that incorrect input type produces error
def test_manager_sell_price_search_error():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data.csv
    list_1.load_from_file("sample_data.csv")
    try:
        list_1.search_by_sell_price(1)
    except TypeError:
        print("              Invalid sell_price type (int) produces TypeError")


"""Test : ItemManager discount type test (Normal, Boundary and Error Cases)"""


# Checks that correct input type is processed correctly
def test_manager_discount_normal():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Mango is originally 1.0, so the discount of 10% would make it 0.9
    list_1.apply_discount_to_items(["Mango"], 10)
    assert list_1.search_by_sell_price(0.9) == [Item("Mango", "Food", True, 1, 0.9)]


# Checks that incorrect input type produce errors
def test_manager_discount_error():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Mango is originally 1.0, so the discount of 10% would make it 0.9
    try:
        list_1.apply_discount_to_items("Mango", 10)
    except TypeError:
        print("              Invalid names type (str) produces TypeError")
    try:
        list_1.apply_discount_to_items(["Mango"], 5.5)
    except TypeError:
        print("              Invalid discount type (float) produces TypeError")
    try:
        list_1.apply_discount_to_items(["Mango"], -5)
    except IOError:
        print("              Invalid discount input (negative) produces TypeError")
    try:
        list_1.apply_discount_to_items(["Mango"], 55)
    except IOError:
        print("              Invalid discount input (above 50) produces TypeError")


# Checks that correct input type on the lower boundary of allowed inputs is processed correctly
def test_manager_discount_boundary_lower():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Mango is originally 1.0, so the discount of 1% would make it 0.99
    list_1.apply_discount_to_items(["Mango"], 1)
    assert list_1.search_by_sell_price(0.99) == [Item("Mango", "Food", True, 1, 0.99)]


# Checks that correct input type on the upper boundary of allowed inputs is processed correctly
def test_manager_discount_boundary_upper():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Mango is originally 1.0, so the discount of 49% would make it 0.51
    list_1.apply_discount_to_items(["Mango"], 49)
    assert list_1.search_by_sell_price(0.51) == [Item("Mango", "Food", True, 1, 0.51)]


"""Test : ItemManager purchase_available_items output test (Normal, Boundary and Error Cases)"""


# Checks that item with sufficient stock can be purchased and stock decreases by one
def test_manager_purchase_normal_1():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Item "Apple" has 2 stock initially
    list_1.purchase_available_items(["Apple"], False)
    stock_check = list_1.search_by_sell_price(1.5)
    assert stock_check == [Item("Apple", "Food", True, 1, 1.5)]


# Checks that two of the same items with sufficient stock can be purchased and stock decreases by 2
def test_manager_purchase_normal_2():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Item "Apple" has 2 stock initially
    list_1.purchase_available_items(["Apple", "Apple"], False)
    stock_check = list_1.search_by_sell_price(1.5)
    assert stock_check == [Item("Apple", "Food", True, 0, 1.5)]


# Checks Item with 0 stock cannot be purchased
def test_manager_purchase_error():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    list_1.add_item(Item("Grapes", "Food", True, 0, 2.0))
    try:
        list_1.purchase_available_items(["Grapes"], False)
    except ValueError:
        print("              Item with 0 stock produces ValueError")


# Checks that purchase goes through on boundary cases (1 stock) and decrements stock to 0
def test_manager_purchase_boundary():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Mango has 1 stock initially
    list_1.purchase_available_items(["Mango"], False)
    stock_check = list_1.search_by_sell_price(1.0)
    assert stock_check == [Item("Mango", "Food", True, 0, 1.0)]


"""Test : ItemManager purchase_available_items total output test (Boundary and Normal Case)"""
# Only boundary and normal case as erroneous inputs have already been explored in previous tests


# Checks that boundary case ($50 total) produces the correct amount of discount
# and that normal cases (is_member = false and is_member = true) produce the
# correct output
def test_manager_purchase_total():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Apple costs 1.5, as not a member it would still cost 1.5
    assert list_1.purchase_available_items(["Apple"], False) == 1.5
    # Mango costs 1.0 which is below 50, therefore the total should be 0.95 as a member
    assert list_1.purchase_available_items(["Mango"], True) == 0.95
    # Increases Mango stock in order to test is_member
    list_1.edit_item(Item("Mango", "Food", True, 1, 1.0), Item("Mango", "Food", True, 50, 1.0))
    # Each mango costs 1.0, so purchasing 50 would total 50, and therefore a 10% discount should be applied
    # this would have a final total of 45
    item_list = []
    for i in range(0,50):
        item_list.append("Mango")
    assert list_1.purchase_available_items(item_list, True) == 45


"""Test : ItemManager purchase_available_items type test (Error Case)"""
# Only error case as correct input types have already been explored in previous tests


# Checks that incorrect input type produces error
def test_manager_purchase_type_normal():
    print("")
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    try:
        list_1.purchase_available_items("Mango", True)
    except TypeError:
        print("              Invalid names type (str) produces TypeError")
    try:
        list_1.purchase_available_items(["Mango"], "True")
    except TypeError:
        print("              Invalid is_member type (str) produces TypeError")


"""Test : ItemManager save_to_file type test (Normal and Error Cases)"""


# Checks that correct input type when saving to file is processed correctly
def test_manager_save_normal():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv
    list_1.load_from_file("sample_data_2.csv")
    # Saves contents of sample_data_2 to sample_data_3
    list_1.save_to_file("sample_data_3.csv")
    # As list_2 is loading from sample_data_3, it should only have the items "Apple" and "Mango"
    list_2 = ItemManager()
    list_2.load_from_file("sample_data_3.csv")
    assert list_2.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Mango", "Food", True, 1, 1.0)]
    # This empty's the sample_data_3 file again, and checks that an empty
    list_2 = ItemManager()
    list_2.save_to_file("sample_data_3.csv")
    assert list_2.get_items() == []


# Checks that incorrect input type when saving to file produces a type error
def test_manager_save_error():
    print("")
    list_1 = ItemManager()
    try:
        list_1.save_to_file(True)
    except TypeError:
        print("              Invalid file_name type (boolean) produces TypeError")


"""Test : ItemManager load_from_file type test (Normal and Error Cases)"""


# Checks that correct input type when loading to file is processed correctly
def test_manager_load_normal():
    list_1 = ItemManager()
    # Contains items from sample_data_2.csv (Apple and Mango)
    list_1.load_from_file("sample_data_2.csv")
    # Checks that list_1 now contains the data stored in sample_data_2
    assert list_1.get_items() == [Item("Apple", "Food", True, 2, 1.5), Item("Mango", "Food", True, 1, 1.0)]


# Checks that incorrect input type when loading from file produces a type error
def test_manager_load_error():
    print("")
    list_1 = ItemManager()
    try:
        list_1.load_from_file(True)
    except TypeError:
        print("              Invalid file_name type (boolean) produces TypeError")
